"""Grid scan + inversion: map (eps, F) -> n_s, alpha_s and invert against datasets."""
import json
import numpy as np
from knobs import solve_x, ns_exact, alpha_eq55, alpha_eq63, NS_THEORY_ERR

# ---------------- grid ----------------
N_EPS, N_F = 140, 140
LOG_EPS = np.linspace(0.0, 6.0, N_EPS)      # eps = 1 .. 1e6
LOG_F = np.linspace(0.0, 15.0, N_F)         # F = 1 .. 1e15
EPS = 10.0**LOG_EPS
F = 10.0**LOG_F

X = np.empty((N_EPS, N_F))
NS = np.empty((N_EPS, N_F))
AL55 = np.empty((N_EPS, N_F))
for i, e in enumerate(EPS):
    for j, f in enumerate(F):
        x = solve_x(e, f)
        X[i, j] = x
        NS[i, j] = ns_exact(e, x)
        AL55[i, j] = alpha_eq55(e, x)
AL63 = alpha_eq63(NS)

# eps -> infinity column (analytic limit of Eqs 53/54)
def solve_x_inf(ff):
    from knobs import rhs_ln, LHS
    from scipy.optimize import brentq
    import numpy as np
    target = np.log(LHS)
    g = lambda lx: (np.log(5.0/(9.0*np.pi**5*(ff*3.91)))
                    + 2.0*lx - 3.0*np.log(2.35e-4)
                    + 4.0*np.sqrt(3.0*np.exp(lx))
                    - 2.0*np.log(1.0 + 2.0*np.sqrt(np.exp(lx)/3.0))) - target
    lo, hi = np.log(5.0), np.log(5e6)
    return np.exp(brentq(g, lo, hi, xtol=1e-12, rtol=1e-12))

def ns_inf(x):
    s = np.sqrt(x/3.0)
    return 1.0 - (1.0 + 4.0*s)/(1.0 + 4.0*s + 8.0*x/3.0)

X_INF = np.array([solve_x_inf(f) for f in F])
NS_INF = ns_inf(X_INF)
AL55_INF = -3.0/(8.0*X_INF)

print(f"grid ranges: n_s in [{NS.min():.5f}, {NS.max():.5f}], "
      f"alpha55 in [{AL55.min():.2e}, {AL55.max():.2e}]")
print(f"eps->inf column: n_s in [{NS_INF.min():.5f}, {NS_INF.max():.5f}]")

# ---------------- datasets ----------------
# (name, central n_s, sigma_obs, note)
DATASETS = [
    ("planck_pr3", 0.9649, 0.0042,
     "published PR3 TT,TE,EE+lowE+lensing (local Cobaya fit: 0.964777)"),
    ("act_dr6_local", 0.968018, 0.006,
     "local ACT DR6 CMB-only fit; sigma = published ACT-alone error as proxy"),
    ("act_dr6_published", 0.973, 0.006,
     "published ACT-alone, Louis et al. arXiv:2503.14452"),
    ("p_act_lb", 0.9743, 0.0034,
     "published P-ACT-LB combination, Louis et al. arXiv:2503.14452"),
]
ALPHA_DATA = ("planck2018_running", -0.0045, 0.0067,
              "Planck 2018 VI, arXiv:1807.06209, TT,TE,EE+lowE+lensing")

np.savez("results/grid.npz", log_eps=LOG_EPS, log_F=LOG_F,
         X=X, NS=NS, AL55=AL55, X_inf=X_INF, NS_inf=NS_INF, AL55_inf=AL55_INF)

out = {"formulas": {
           "ns": "Eq(54) exact: ns-1 = -[1+2(1+2e)/(1+e)*sqrt(x/3)]/[1+(2+4e)/(1+e)*sqrt(x/3)+8*e*x/(3(1+e))]",
           "x": "Eq(53): P/k^3 = 5*6^(2/e)/(9 pi^5 F g0) * x^(2+2/e)/T0^3 * exp(4 sqrt(3x))/(1+2 sqrt(x/3))^2; F=reheat entropy factor",
           "alpha": "Eq(55): alpha_s = -3(1+2e)/(16 e x)",
           "pivot": "k=0.05 Mpc^-1, P=2.142e-9, g0=3.91, T0=2.35e-4 eV"},
       "grid": {"log10_eps": [0.0, 6.0], "log10_F": [0.0, 15.0],
                "n_eps": N_EPS, "n_F": N_F, "npz": "results/grid.npz"},
       "alpha_data": {"name": ALPHA_DATA[0], "value": ALPHA_DATA[1],
                      "sigma": ALPHA_DATA[2], "note": ALPHA_DATA[3]},
       "datasets": {}}

for name, mu, sig, note in DATASETS:
    sig_tot = float(np.sqrt(sig**2 + NS_THEORY_ERR**2))
    entry = {"ns_central": mu, "ns_sigma_obs": sig,
             "ns_sigma_tot": sig_tot, "note": note, "bands": {}}
    for z, tag in ((1.0, "1sigma"), (2.0, "2sigma")):
        mask = np.abs(NS - mu) <= z*sig_tot
        mask_inf = np.abs(NS_INF - mu) <= z*sig_tot
        # allowed eps range at F=1 (first F column)
        col = mask[:, 0]
        # allowed F range at eps->inf
        entry["bands"][tag] = {
            "n_cells": int(mask.sum()),
            "frac_grid": float(mask.mean()),
            # eps allowed at F=1:
            "eps_allowed_at_F1": ([float(EPS[col][0]), float(EPS[col][-1])]
                                  if col.any() else None),
            # F allowed at eps->inf:
            "F_allowed_at_eps_inf": ([float(F[mask_inf][0]), float(F[mask_inf][-1])]
                                     if mask_inf.any() else None),
        }
        if tag == "1sigma":
            ii, jj = np.unravel_index(np.abs(NS - mu).argmin(), NS.shape)
            entry["best_grid_point"] = {
                "eps": float(EPS[ii]), "F": float(F[jj]),
                "ns_model": float(NS[ii, jj]),
                "resid_sigma": float(abs(NS[ii, jj]-mu)/sig_tot)}
            ji = int(np.abs(NS_INF - mu).argmin())
            entry["best_eps_inf"] = {"F": float(F[ji]),
                                     "ns_model": float(NS_INF[ji])}
    out["datasets"][name] = entry
    b1 = entry["bands"]["1sigma"]
    print(f"{name}: mu={mu}, sig_tot={sig_tot:.4f}")
    print(f"   1sig frac={b1['frac_grid']:.3f}  eps@F=1: {b1['eps_allowed_at_F1']}  "
          f"F@epsinf: {b1['F_allowed_at_eps_inf']}")

with open("results/knobs.json", "w") as fh:
    json.dump(out, fh, indent=2)
print("wrote results/knobs.json and results/grid.npz")
