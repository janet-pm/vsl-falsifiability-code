"""
Knob-fit for the Afshordi-Magueijo (2016) bimetric VSL model, arXiv:1603.03312.

Extracted formulas (equation numbers refer to the v2 arXiv source,
Bim-thermal_PRD_complete.tex; main-text numbers in brackets):

  Eq (53) [cf. main-text Eq (20)] -- amplitude/entropy matching, fixes x = B0*rho
          at horizon crossing of the pivot mode:
    P_zeta/k^3 = (5 * 6^(2/eps)) / (9*pi^5 * g0) * x^(2+2/eps) / T0^3
                 * exp(4*sqrt(3*x)) / (1 + 2*sqrt(x/3))^2
  Reheating (entropy injection by factor F after the varying-c phase) enters as
  g0 -> F*g0  [main text: "we have assumed no 'reheating' at the end of the
  varying-c phase"; Eq (48) is the entropy-conservation relation].

  Eq (54) [main-text Eq "ns_model"] -- exact tilt:
    n_s - 1 = -[1 + (2*(1+2*eps)/(1+eps)) * sqrt(x/3)]
              / [1 + ((2+4*eps)/(1+eps)) * sqrt(x/3) + 8*eps*x/(3*(1+eps))]
  Leading order: n_s - 1 = -((1+2*eps)/(4*eps)) * (x/3)^(-1/2) + O(1/x).

  Eq (55) [main-text discussion around Eq (22)] -- running:
    alpha_s = dn_s/dlnk = -(3/(16*eps)) * (1+2*eps)/x + O(x^(-3/2)).

CAVEAT (internal inconsistency in the paper): the main text Eq (22) and the
appendix Eq (63) claim alpha_s = -3/2*(n_s-1)^2 ~ -1.8e-3, but the paper's own
derived leading-order result Eq (55) gives -3*(1+2*eps)/(16*eps*x), which at
(eps->inf, x=583.03) is -6.4e-4 -- a factor ~3 smaller. The derivation from
Eqs (17),(19),(47) reproduces Eq (55), so Eq (55) is used here and the
discrepancy is flagged. It does not affect any constraint (data error on
alpha_s is +-0.0067).

Conventions: pivot k = 0.05 Mpc^-1 = 3.198e-31 eV [Eq (57)];
P_zeta = 2.142e-9 [Eq (56)]; g0 = 3.91, T0 = 2.35e-4 eV [Eq (49)].
"""

import numpy as np
from scipy.optimize import brentq

# ---- constants (paper Eqs 49, 56, 57) ----
G0 = 3.91            # relativistic d.o.f. today
T0 = 2.35e-4         # CMB temperature today, eV
K_PIV = 3.198e-31    # pivot k = 0.05 Mpc^-1, eV
P_OBS = 2.142e-9     # observed scalar amplitude at pivot
NS_THEORY_ERR = 0.00064  # quoted theory uncertainty on n_s (Eq 21/59)

LHS = P_OBS / K_PIV**3   # observed P_zeta / k^3  [eV^-3]


def rhs_ln(x, eps, F):
    """ln of RHS of Eq (53) with reheating entropy factor F (g0 -> F*g0)."""
    g = F * G0
    return (np.log(5.0 * 6.0**(2.0/eps) / (9.0*np.pi**5 * g))
            + (2.0 + 2.0/eps)*np.log(x)
            - 3.0*np.log(T0)
            + 4.0*np.sqrt(3.0*x)
            - 2.0*np.log(1.0 + 2.0*np.sqrt(x/3.0)))


def solve_x(eps, F):
    """Solve Eq (53) for x = B0*rho at crossing. RHS is monotonic in x."""
    target = np.log(LHS)
    f = lambda lx: rhs_ln(np.exp(lx), eps, F) - target
    lo, hi = np.log(5.0), np.log(5e6)
    assert f(lo) < 0 < f(hi), f"no bracket for eps={eps}, F={F}"
    return np.exp(brentq(f, lo, hi, xtol=1e-12, rtol=1e-12))


def ns_exact(eps, x):
    """Eq (54), exact tilt formula."""
    s = np.sqrt(x/3.0)
    num = 1.0 + (2.0*(1.0+2.0*eps)/(1.0+eps))*s
    den = (1.0 + ((2.0+4.0*eps)/(1.0+eps))*s
           + 8.0*eps*x/(3.0*(1.0+eps)))
    return 1.0 - num/den


def ns_leading(eps, x):
    """Eq (54), leading-order form."""
    return 1.0 - ((1.0+2.0*eps)/(4.0*eps)) * (x/3.0)**(-0.5)


def alpha_eq55(eps, x):
    """Eq (55), derived running."""
    return -(3.0/(16.0*eps)) * (1.0+2.0*eps)/x


def alpha_eq63(ns):
    """Main-text Eq (22) / appendix Eq (63) claim: -3/2 (n_s-1)^2."""
    return -1.5*(ns-1.0)**2


def knobs(eps, F):
    """Full pipeline: (eps, F) -> (x, n_s, alpha_s)."""
    x = solve_x(eps, F)
    ns = ns_exact(eps, x)
    return x, ns, alpha_eq55(eps, x)


if __name__ == "__main__":
    INF = 1e10
    # --- sanity 1: critical model, no reheat -> x ~= 583.03, n_s = 0.96478 ---
    x, ns, al = knobs(INF, 1.0)
    print(f"(eps->inf, F=1): x={x:.3f} (paper 583.03), "
          f"n_s={ns:.5f} (paper 0.96478), alpha55={al:.3e}, alpha63={alpha_eq63(ns):.3e}")
    assert abs(x - 583.03) < 1.0, "x mismatch"
    assert abs(ns - 0.96478) < 2e-4, "n_s mismatch"

    # --- sanity 2: eps=2, no reheat -> n_s = 0.95292 (paper) ---
    x2, ns2, al2 = knobs(2.0, 1.0)
    print(f"(eps=2, F=1):     x={x2:.2f}, n_s={ns2:.5f} (paper 0.95292), alpha55={al2:.3e}")

    # --- sanity 3: reheat by 1e10 -> n_s = 0.96838 (paper, eps->inf assumed) ---
    x3, ns3, al3 = knobs(INF, 1e10)
    print(f"(eps->inf, F=1e10): x={x3:.2f}, n_s={ns3:.5f} (paper 0.96838), alpha55={al3:.3e}")

    # --- sanity 4: leading-order vs exact gap = quoted theory error ---
    print(f"exact-LO gap at critical point: {ns - ns_leading(INF, x):.2e} (paper: 6.4e-4)")
