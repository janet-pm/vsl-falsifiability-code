"""Plots for the knob-fit report."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

g = np.load("results/grid.npz")
LE, LF = g["log_eps"], g["log_F"]
EPS, F = 10.0**LE, 10.0**LF
NS, AL55 = g["NS"], g["AL55"]
NS_INF, X_INF, AL55_INF = g["NS_inf"], g["X_inf"], g["AL55_inf"]
AL63 = -1.5*(NS-1.0)**2
AL63_INF = -1.5*(NS_INF-1.0)**2

DS = [
    ("Planck PR3", 0.9649, 0.0042, "C0"),
    ("ACT DR6 (local)", 0.968018, 0.0060, "C1"),
    ("ACT DR6 (publ.)", 0.973, 0.0060, "C2"),
    ("P-ACT-LB", 0.9743, 0.0034, "C3"),
]
SIG_T = 0.00064

# ---------- Fig 1: contour map with dataset bands ----------
fig, ax = plt.subplots(figsize=(9, 6.5))
cf = ax.contourf(LE, LF, NS.T, levels=24, cmap="RdYlBu_r", vmin=0.942, vmax=0.971)
cb = fig.colorbar(cf, ax=ax, label=r"$n_s(\epsilon, F)$  [Eq (54) exact]")
ax.contour(LE, LF, NS.T, levels=[0.95, 0.96, 0.96478, 0.97], colors="k",
           linewidths=0.8, linestyles="--")
for name, mu, sig, col in DS:
    st = np.sqrt(sig**2 + SIG_T**2)
    ax.contour(LE, LF, np.abs(NS-mu).T, levels=[st], colors=[col], linewidths=2.2)
    ax.contour(LE, LF, np.abs(NS-mu).T, levels=[2*st], colors=[col],
               linewidths=1.1, linestyles=":")
# paper variant points
h1, = ax.plot([np.log10(2)], [0], "w*", ms=13, mec="k",
              label=r"paper: $\epsilon=2$ (LO: 0.95292)")
h2, = ax.plot([6.0], [10.0], "wD", ms=9, mec="k",
              label=r"paper: $F=10^{10}$ (LO: 0.96838)")
ax.annotate("minimal model\n"+r"$(\epsilon\!\to\!\infty, F\!=\!1)$"+"\n$n_s=0.96478$",
            xy=(6.0, 0.0), xytext=(4.35, 2.2),
            arrowprops=dict(arrowstyle="->", color="white", lw=1.5),
            color="white", fontsize=9, ha="center",
            bbox=dict(boxstyle="round", fc="black", alpha=0.55, ec="none"))
ax.set_xlabel(r"$\log_{10}\,\epsilon$  (bimetric gravity-sector parameter)")
ax.set_ylabel(r"$\log_{10}\,F$  (reheating entropy-injection factor)")
ax.set_title("Bimetric VSL knob space: solid = dataset 1-sigma bands, dotted = 2-sigma")
DS_SHORT = ["Planck PR3", "ACT DR6 (local)", "ACT DR6 (publ.)", "P-ACT-LB"]
for (name, mu, sig, col), lab in zip(DS, DS_SHORT):
    ax.plot([], [], color=col, lw=2.2, label=lab)
ax.legend(loc="upper left", fontsize=8, framealpha=0.92, ncol=2,
          handletextpad=0.4, columnspacing=1.0)
fig.tight_layout()
fig.savefig("results/fig_contours.png", dpi=150)
print("wrote results/fig_contours.png")

# ---------- Fig 2: slices ----------
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.2), sharey=True)
a1.semilogx(F, NS_INF, "k-", lw=2, label=r"model, $\epsilon\to\infty$")
for name, mu, sig, col in DS:
    st = np.sqrt(sig**2 + SIG_T**2)
    a1.axhspan(mu-st, mu+st, color=col, alpha=0.25)
    a1.axhline(mu, color=col, ls="--", lw=1)
a1.set_xlabel(r"$F$ (reheating factor), $\epsilon\to\infty$")
a1.set_ylabel(r"$n_s$")
a1.set_title(r"$n_s$ vs reheating at $\epsilon\to\infty$")
a1.set_ylim(0.955, 0.978)
a1.grid(alpha=0.3)

a2.semilogx(EPS, NS[:, 0], "k-", lw=2, label=r"model, $F=1$")
for name, mu, sig, col in DS:
    st = np.sqrt(sig**2 + SIG_T**2)
    a2.axhspan(mu-st, mu+st, color=col, alpha=0.25)
    a2.axhline(mu, color=col, ls="--", lw=1, label=f"{name} 1sig")
a2.set_xlabel(r"$\epsilon$, $F=1$ (no reheating)")
a2.set_title(r"$n_s$ vs $\epsilon$ at $F=1$")
a2.grid(alpha=0.3)
a2.legend(fontsize=7.5, loc="lower right")
fig.suptitle("Slices through knob space (shaded = dataset 1-sigma incl. theory error)")
fig.tight_layout()
fig.savefig("results/fig_slices.png", dpi=150)
print("wrote results/fig_slices.png")

# ---------- Fig 3: running ----------
fig, (b1, b2) = plt.subplots(1, 2, figsize=(11, 4.2))
b1.semilogx(F, AL55_INF*1e3, "k-", lw=2, label="Eq (55)")
b1.semilogx(F, AL63_INF*1e3, "k--", lw=1.5, label="Eq (63): -3/2(ns-1)^2")
b1.axhspan((-0.0045-0.0067)*1e3, (-0.0045+0.0067)*1e3, color="C0", alpha=0.25,
           label="Planck 2018")
b1.axhline(-0.0045*1e3, color="C0", ls="--", lw=1)
b1.set_xlabel(r"$F$, $\epsilon\to\infty$")
b1.set_ylabel(r"$\alpha_s = dn_s/d\ln k\ \times 10^3$")
b1.set_title("Running vs reheating")
b1.legend(fontsize=8); b1.grid(alpha=0.3)
b2.semilogx(EPS, AL55[:, 0]*1e3, "k-", lw=2, label="Eq (55)")
b2.semilogx(EPS, AL63[:, 0]*1e3, "k--", lw=1.5, label="Eq (63)")
b2.axhspan((-0.0045-0.0067)*1e3, (-0.0045+0.0067)*1e3, color="C0", alpha=0.25)
b2.axhline(-0.0045*1e3, color="C0", ls="--", lw=1)
b2.set_xlabel(r"$\epsilon$, $F=1$")
b2.set_title("Running vs epsilon")
b2.legend(fontsize=8); b2.grid(alpha=0.3)
fig.suptitle("Model running is far below data sensitivity: alpha_s cannot break the degeneracy")
fig.tight_layout()
fig.savefig("results/fig_alpha.png", dpi=150)
print("wrote results/fig_alpha.png")
