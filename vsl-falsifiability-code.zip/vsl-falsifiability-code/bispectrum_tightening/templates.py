"""
Primordial bispectrum templates for the independent Fisher redo.

Conventions (re-derived from Mylova et al., arXiv:2112.08179, NOT copied
from the original forecast code):
  - Shape function (their Eq. 6.2): S = (k1 k2 k3)^2 B_Phi / A^2,
    A = dimensionless power amplitude, P_Phi(k) = A/k^3.
  - Phi = (3/5) zeta  =>  zeta = (5/3) Phi, B_zeta = (5/3)^3 B_Phi.
  - A = (9/25)(2 pi^2 A_s) since P_Phi = (9/25) P_zeta.
  - Hence B_zeta = (5/3)^3 * S * A^2/(k1k2k3)^2
                = 0.6 * (2 pi^2 A_s)^2 * S/(k1k2k3)^2.
    Check: (125/27)*(81/625) = (125*81)/(27*625) = 3/5 = 0.6. Yes.

Flattened shape (their Sec. 6): on the symmetric isosceles fold
(x2 = k2/k1 = 1, x3 = k3/k1 -> 2) the shape diverges as
    S -> C_fold * ((k1+k2-k3)/k1)^(-3/2),  C_fold = -3*pi/4,
derived analytically from their Eq. 6.9 (see derivation in REDO.md and
the numerical check `check_fold_coefficient()` below, which implements
Eq. 6.9 directly from the arXiv LaTeX source).

OUR template definition (independent normalization choice):
    S_fold(k1,k2,k3; delta) = sum over 3 perms of
        [ ((k_a+k_b-k_c)/(k_a+k_b))^2 + delta^2 ]^(-3/4)
    B_zeta^flat = 0.6*(2 pi^2 A_s)^2 * (C_fold/2**(3/2)) * S_fold/(k1k2k3)^2
The 2^(-3/2) makes the delta->0 limit match the paper's folded amplitude
exactly on the symmetric fold: ((k1+k2-k3)/(k1+k2)) = eps_p/2 where
eps_p = (k1+k2-k3)/k1 is the paper's expansion variable, so
[(eps_p/2)^2]^(-3/4) = 2^(3/2) eps_p^(-3/2), cancelled by the prefactor.
f_NL^flat = 1  <=>  exactly this normalization (the paper's prediction).

delta is therefore the FRACTIONAL regulator relative to (k_a+k_b),
the sum of the two non-folded sides for each permutation.
Mapping to other k_ref choices: delta_other = delta_here * (k_ref/(k_a+k_b)).
"""
import numpy as np

C_FOLD = -3.0 * np.pi / 4.0          # paper's folded coefficient, x2 = 1
NORM_CORR = 2.0 ** (-1.5)             # 2^(-3/2), see module docstring


def _prefactor(As):
    return 0.6 * (2.0 * np.pi**2 * As) ** 2


def Bzeta_local(k1, k2, k3, Pzeta, fNL=1.0):
    """Local primordial bispectrum (derivative wrt fNL at fNL=1).
    B_zeta = (6/5) fNL [Pz1 Pz2 + Pz2 Pz3 + Pz3 Pz1]."""
    Pz1, Pz2, Pz3 = Pzeta(k1), Pzeta(k2), Pzeta(k3)
    return (6.0 / 5.0) * fNL * (Pz1 * Pz2 + Pz2 * Pz3 + Pz3 * Pz1)


def S_fold_raw(k1, k2, k3, delta):
    """Dimensionless regulated folded-shape sum (no amplitude prefactor)."""
    k1 = np.asarray(k1, dtype=float)
    k2 = np.asarray(k2, dtype=float)
    k3 = np.asarray(k3, dtype=float)
    t1 = ((k2 + k3 - k1) / (k2 + k3)) ** 2 + delta**2
    t2 = ((k1 + k3 - k2) / (k1 + k3)) ** 2 + delta**2
    t3 = ((k1 + k2 - k3) / (k1 + k2)) ** 2 + delta**2
    return t1 ** (-0.75) + t2 ** (-0.75) + t3 ** (-0.75)


def Bzeta_flat(k1, k2, k3, As, delta, fNL=1.0):
    """Flattened primordial bispectrum (derivative wrt fNL^flat at 1)."""
    k1 = np.asarray(k1, dtype=float)
    k2 = np.asarray(k2, dtype=float)
    k3 = np.asarray(k3, dtype=float)
    S = S_fold_raw(k1, k2, k3, delta)
    return fNL * _prefactor(As) * (C_FOLD * NORM_CORR) * S / (k1 * k2 * k3) ** 2


# ---------------------------------------------------------------------------
# Direct implementation of the paper's Eq. 6.9, transcribed from the arXiv
# LaTeX source (2112.08179, main.tex, eq:ng8). Used ONLY to validate the
# folded coefficient C_fold = -3*pi/4 and our template normalization.
# S_bi-thermal(x2, x3), x2 = k2/k1, x3 = k3/k1.
# ---------------------------------------------------------------------------
def S_eq69(x2, x3):
    x2 = np.asarray(x2, dtype=float)
    x3 = np.asarray(x3, dtype=float)
    u = 1.0 + x2
    D = u - x3
    E = u + x3
    den = 8.0 * x2 * x3**2 * D**1.5 * E**1.5
    poly = u**3 + 4.0 * u**2 * x3 + 4.0 * u * x3**2 - 8.0 * x3**3
    # arccsc(z) = arcsin(1/z); argument (1+x2)/x3 >= 1 near the fold
    arc = np.arcsin(x3 / u)
    bracket = (x3 * np.sqrt(D * E) * poly
               + u**3 * (u - 2.0 * x3)**2 * arc)
    return -1.0 / den * (3.0 * u**2 * bracket)


def check_fold_coefficient(eps_vals=(0.1, 0.03, 0.01, 0.003)):
    """Fit S_eq69(x2=1, x3=2-eps) * eps**(3/2) -> should approach C_fold."""
    print("Eq.6.9 folded-limit check (x2=1, x3 -> 2-):")
    print(f"  expected C_fold = {C_FOLD:.6f}")
    for eps in eps_vals:
        S = S_eq69(1.0, 2.0 - eps)
        inferred = S * eps**1.5
        print(f"  eps={eps:<7}  S*eps^1.5 = {inferred:.6f}  "
              f"(rel. err {(inferred - C_FOLD)/C_FOLD:+.2%})")
    # template normalization check: our regulated template vs Eq.6.9
    print("Template-vs-paper amplitude check on the symmetric fold:")
    As = 2.1e-9
    for eps in eps_vals:
        k = 1.0
        Sraw = S_fold_raw(k, k, 2*k - eps*k, delta=1e-4)
        # our template's shape amplitude in units of C_fold*eps^-1.5:
        # NORM_CORR*Sraw -> eps^-1.5, so *eps^1.5 -> 1
        amp_template = NORM_CORR * Sraw * eps**1.5
        S69 = S_eq69(1.0, 2.0 - eps)
        amp_paper = S69 * eps**1.5 / C_FOLD   # -> 1 if paper matches C_fold
        print(f"  eps={eps:<7}  template/C_fold -> {amp_template:.6f}, "
              f"paper/C_fold -> {amp_paper:.6f}")


if __name__ == "__main__":
    check_fold_coefficient()
