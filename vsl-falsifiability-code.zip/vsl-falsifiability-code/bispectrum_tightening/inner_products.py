"""Fisher inner products: F_LL, F_FF, F_LF and the ChatGPT overlap-scaling analog.

ChatGPT's estimate: sigma_flat ~= sigma_local / |r|, where r is the
template cosine. This implicitly assumes ||flat||_Fisher == ||local||_Fisher.
We compute the actual norms and show the missing norm ratio.
"""
import json
import numpy as np

import fisher
import survey
import templates


def inner_product(eng, which1, which2, delta=None, N=600000, seed=0):
    """F_{12} = V/8pi^4 < w k1k2k3 dB1 dB2 / (P1P2P3) > over MC triangles."""
    k1, k2, k3, w0 = fisher._sample_triangles_mc(
        eng, N, delta=delta, seed=seed)
    ok = w0 > 0
    k1, k2, k3, w0 = k1[ok], k2[ok], k3[ok], w0[ok]
    Pg1, Pg2, Pg3 = eng.Pg(k1), eng.Pg(k2), eng.Pg(k3)

    def dB(which):
        M1, M2, M3 = eng.M(k1), eng.M(k2), eng.M(k3)
        b = eng.spec["b_eff"]
        if which == "local":
            dBz = templates.Bzeta_local(k1, k2, k3, eng.Pzeta, fNL=1.0)
        else:
            dBz = templates.Bzeta_flat(k1, k2, k3, survey.COSMO["As"],
                                       delta, fNL=1.0)
        return b**3 * M1 * M2 * M3 * dBz

    d1, d2 = dB(which1), dB(which2)
    integ = w0 * k1 * k2 * k3 * d1 * d2 / (Pg1 * Pg2 * Pg3)
    # Full labeled cube -> unique triangles: divide by 6.
    F = eng.spec["V"] / fisher._TWO_PI4 / 6.0 * integ.mean()
    Ferr = eng.spec["V"] / fisher._TWO_PI4 / 6.0 * integ.std() / np.sqrt(len(integ))
    return F, Ferr


def main():
    engines = [fisher.BinEngine(ibin) for ibin in range(6)]
    out = {}
    for delta in [0.10, 0.05, 0.02, 0.01]:
        FLL = FFF = FLF = 0.0
        for ibin, eng in enumerate(engines):
            f11, _ = inner_product(eng, "local", "local", seed=7000 + ibin)
            f22, _ = inner_product(eng, "flat", "flat", delta=delta,
                                   seed=8000 + ibin)
            f12, _ = inner_product(eng, "local", "flat", delta=delta,
                                   seed=9000 + ibin)
            FLL += f11
            FFF += f22
            FLF += f12
        r = FLF / np.sqrt(FLL * FFF)
        sig_local = 1.0 / np.sqrt(FLL)
        sig_flat_actual = 1.0 / np.sqrt(FFF)
        sig_chatgpt = sig_local / abs(r)
        norm_ratio = np.sqrt(FFF / FLL)
        out[str(delta)] = dict(
            F_LL=FLL, F_FF=FFF, F_LF=FLF, cosine=r,
            norm_ratio_FF_LL=norm_ratio,
            sigma_local=sig_local,
            sigma_flat_actual=sig_flat_actual,
            sigma_chatgpt_analog=sig_chatgpt,
            discrepancy_factor=sig_chatgpt / sig_flat_actual,
        )
        print(f"delta={delta}: cosine r={r:.4f}, "
              f"||F||/||L||={norm_ratio:.2f}, "
              f"sig_local={sig_local:.3f}, "
              f"ChatGPT sig_flat~{sig_chatgpt:.3f} "
              f"({1/sig_chatgpt:.1f}σ), "
              f"actual sig_flat={sig_flat_actual:.3f} "
              f"({1/sig_flat_actual:.1f}σ), "
              f"gap={sig_chatgpt/sig_flat_actual:.1f}x", flush=True)
    with open("../results/inner_products.json", "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
