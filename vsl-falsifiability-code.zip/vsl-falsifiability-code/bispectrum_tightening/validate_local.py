"""Local-shape validation: reproduce ~published SPHEREx sigma(fNL^local).

Published targets (Heinrich et al. 2311.13082):
  sigma = 0.73 : full multitracer redshift-space bispectrum, 5 samples x 6
                 z-bins, marginalized over {As, ns, nrun, fNL, Obh2, Och2,
                 100thetaMC, b10^X (55 biases)}
  sigma = 0.7  : fiducial quoted (bispectrum only)
  sigma = 0.5  : with power spectrum added (not our target; we do B-only)

Our pipeline: effective single tracer per z-bin, real-space tree-level,
single-parameter Fisher (fNL only, cosmology+bias fixed), no RSD, no
photo-z damping, no multitracer, no PS info. See REDO.md for the honest
comparison and the direction of each omission.
"""
import json
import time
import numpy as np

import fisher
import survey

NBINS = 6


def run_local(N=600000, seed=100):
    per_bin = []
    Ftot = 0.0
    for ibin in range(NBINS):
        t0 = time.time()
        eng = fisher.BinEngine(ibin)
        F, Ferr = fisher.fisher_mc(eng, "local", N=N, seed=seed + ibin)
        sig = 1.0 / np.sqrt(F)
        per_bin.append(dict(ibin=ibin, zmin=eng.spec["zmin"],
                            zmax=eng.spec["zmax"],
                            V_Gpc3h=eng.spec["V"] / 1e9,
                            kmin=eng.spec["kmin"], kmax=eng.spec["kmax"],
                            n_eff=eng.spec["n_eff"], b_eff=eng.spec["b_eff"],
                            F=F, Ferr=Ferr, sigma=sig))
        Ftot += F
        print(f"bin {ibin} z=[{eng.spec['zmin']:.1f},{eng.spec['zmax']:.1f}] "
              f"V={eng.spec['V']/1e9:.2f} (Gpc/h)^3 "
              f"kmax={eng.spec['kmax']:.3f} n_eff={eng.spec['n_eff']:.3e} "
              f"b_eff={eng.spec['b_eff']:.2f} -> sigma_local={sig:.3f} "
              f"({time.time()-t0:.1f}s)", flush=True)
    sig_tot = 1.0 / np.sqrt(Ftot)
    print(f"COMBINED 6 bins: F={Ftot:.4f} -> sigma(fNL^local) = {sig_tot:.3f}")
    print("published 2311.13082: 0.73 (multitracer, marginalized), 0.7 fiducial")
    return per_bin, sig_tot


if __name__ == "__main__":
    per_bin, sig_tot = run_local()
    with open("../results/local_validation.json", "w") as f:
        json.dump(dict(per_bin=per_bin, sigma_combined=sig_tot,
                       published_fiducial=0.7, published_marginalized=0.73),
                  f, indent=2)
    print("wrote ../results/local_validation.json")
