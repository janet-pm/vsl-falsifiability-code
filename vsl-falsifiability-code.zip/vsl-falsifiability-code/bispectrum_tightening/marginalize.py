"""
Tree-level gravitational galaxy bispectrum + nuisance-marginalization test.

Used to QUANTIFY (within our own pipeline) how much marginalizing over
bias nuisance parameters degrades f_NL for the local vs flattened shapes.
This is a diagnostic, not part of the primary single-parameter Fisher.

B_g^tree = b1^3 [M1M2M3 B_zeta + Bm_grav] + b1^2 b2 [P1P2+perms]
           + 2 b1^2 bs2 [S2_12 P1P2 + perms]
Bm_grav = 2 F2(k1,k2) P1 P2 + perms
S2(k1,k2) = (k1hat.k2hat)^2 - 1/3
b2(b1): Lazeyras et al. 2016 fit; bs2 = -4/7 (b1-1) (Lagrangian local).

We Fisher-marginalize over (b1, b2) per z-bin with f_NL shared, and
compare marginalized sigma(f_NL) to the single-parameter value, for
local and flattened templates separately.
"""
import numpy as np

import fisher
import survey
import templates


def b2_lazeyras(b1):
    b1 = np.asarray(b1, dtype=float)
    return 0.412 - 2.143 * b1 + 0.929 * b1**2 + 0.008 * b1**3


def bs2_local_lagrangian(b1):
    return -4.0 / 7.0 * (np.asarray(b1, dtype=float) - 1.0)


def F2_kernel(k1, k2, k3):
    """F2(k1,k2) with k3=|k1+k2| via law of cosines. Vectorized."""
    k1 = np.asarray(k1, dtype=float); k2 = np.asarray(k2, dtype=float)
    k3 = np.asarray(k3, dtype=float)
    mu = (k3**2 - k1**2 - k2**2) / (2.0 * k1 * k2)
    mu = np.clip(mu, -1.0, 1.0)
    return 5.0/7.0 + 0.5 * mu * (k1/k2 + k2/k1) + 2.0/7.0 * mu**2


def S2_kernel(k1, k2, k3):
    mu = (k3**2 - k1**2 - k2**2) / (2.0 * k1 * k2)
    mu = np.clip(mu, -1.0, 1.0)
    return mu**2 - 1.0/3.0


class GravityEngine(fisher.BinEngine):
    """BinEngine plus tree-level gravity bispectrum and bias derivatives."""

    def Bg_grav(self, k1, k2, k3):
        """Galaxy bispectrum at f_NL=0 (gravity + nonlinear bias)."""
        b1 = self.spec["b_eff"]
        b2 = b2_lazeyras(b1)
        bs2 = bs2_local_lagrangian(b1)
        P1, P2, P3 = self.Pm(k1), self.Pm(k2), self.Pm(k3)
        Bm = (2*F2_kernel(k1, k2, k3)*P1*P2
              + 2*F2_kernel(k2, k3, k1)*P2*P3
              + 2*F2_kernel(k3, k1, k2)*P3*P1)
        Pb2 = b1**2 * b2 * (P1*P2 + P2*P3 + P3*P1)
        Pbs = 2*b1**2*bs2 * (S2_kernel(k1, k2, k3)*P1*P2
                             + S2_kernel(k2, k3, k1)*P2*P3
                             + S2_kernel(k3, k1, k2)*P3*P1)
        return b1**3 * Bm + Pb2 + Pbs

    def dBg_db1(self, k1, k2, k3):
        b1 = self.spec["b_eff"]
        b2 = b2_lazeyras(b1)
        bs2 = bs2_local_lagrangian(b1)
        db2 = -2.143 + 2*0.929*b1 + 3*0.008*b1**2
        dbs2 = -4.0/7.0
        P1, P2, P3 = self.Pm(k1), self.Pm(k2), self.Pm(k3)
        Bm = (2*F2_kernel(k1, k2, k3)*P1*P2
              + 2*F2_kernel(k2, k3, k1)*P2*P3
              + 2*F2_kernel(k3, k1, k2)*P3*P1)
        S2P = (S2_kernel(k1, k2, k3)*P1*P2 + S2_kernel(k2, k3, k1)*P2*P3
               + S2_kernel(k3, k1, k2)*P3*P1)
        PP = P1*P2 + P2*P3 + P3*P1
        return (3*b1**2 * Bm + (2*b1*b2 + b1**2*db2) * PP
                + (4*b1*bs2 + 2*b1**2*dbs2) * S2P)

    def dBg_db2(self, k1, k2, k3):
        b1 = self.spec["b_eff"]
        P1, P2, P3 = self.Pm(k1), self.Pm(k2), self.Pm(k3)
        return b1**2 * (P1*P2 + P2*P3 + P3*P1)


def _fisher_block_mc(eng, derivs, N=200000, seed=0):
    """Multiparameter Fisher block via MC. derivs: list of dB/dp callables."""
    k1, k2, k3, w0 = fisher._sample_triangles_mc(eng, N, seed=seed)
    ok = w0 > 0
    k1, k2, k3, w0 = k1[ok], k2[ok], k3[ok], w0[ok]
    D = np.array([d(k1, k2, k3) for d in derivs])     # (npar, N)
    Pg = eng.Pg(k1) * eng.Pg(k2) * eng.Pg(k3)
    base = w0 * k1 * k2 * k3 / Pg                      # (N,)
    npar = len(derivs)
    Fmat = np.einsum("iN,jN,N->ij", D, D, base) / len(k1)
    # Full labeled cube -> unique triangles: divide by 6.
    Fmat *= eng.spec["V"] / fisher._TWO_PI4 / 6.0
    return Fmat


def marginalization_penalty(which, delta=None, N=200000, seed=0):
    """Ratio sigma_marg(fNL; b1,b2 free per bin) / sigma_singlepar, per bin."""
    ratios = []
    for ibin in range(6):
        eng = GravityEngine(ibin)
        if which == "local":
            dF = lambda a, b, c: eng.dBg_local(a, b, c)
        else:
            dF = lambda a, b, c, _d=delta: eng.dBg_flat(a, b, c, _d)
        F3 = _fisher_block_mc(eng, [dF, eng.dBg_db1, eng.dBg_db2],
                              N=N, seed=seed + ibin)
        F1 = F3[0, 0]
        cov = np.linalg.inv(F3)
        sig_marg = np.sqrt(cov[0, 0])
        sig_single = 1.0 / np.sqrt(F1)
        ratios.append(sig_marg / sig_single)
        print(f"  bin {ibin}: single={sig_single:.3f} marg={sig_marg:.3f} "
              f"ratio={sig_marg/sig_single:.2f}", flush=True)
    return ratios


if __name__ == "__main__":
    print("LOCAL marginalization over (b1,b2):")
    rl = marginalization_penalty("local", N=150000, seed=200)
    print("FLAT delta=0.05 marginalization over (b1,b2):")
    rf = marginalization_penalty("flat", delta=0.05, N=150000, seed=300)
    print(f"mean local penalty: {np.mean(rl):.2f}, "
          f"mean flat penalty: {np.mean(rf):.2f}")
