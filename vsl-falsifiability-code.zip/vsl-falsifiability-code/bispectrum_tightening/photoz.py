"""Photo-z damping penalty (diagnostic).

Per (bin, sample): D_A(k) = exp(-k^2 sig_chi^2/6), angle-averaged redshift-
space damping; sig_chi = c*sig_z/H(z). Bispectrum gets D1*D2*D3, power
spectra get D^2. Compares Fisher with/without damping, per sample, summed.
"""
import numpy as np

import fisher
import survey
import templates

C_KMS = 299792.458

# photo-z error sigma_z/(1+z) per sample (2311.13082 Table 1)
SIGZ_REL = np.array([0.003, 0.01, 0.03, 0.1, 0.2])

# background H(z) in km/s/Mpc, flat LCDM
_OM = (survey.COSMO["ombh2"] + survey.COSMO["omch2"]) / survey.H**2
_OL = 1.0 - _OM


def Hz_kms(z):
    return survey.COSMO["H0"] * np.sqrt(_OM * (1 + z)**3 + _OL)


def damping_D(ibin, isamp, k):
    zmin, zmax = survey.Z_BINS[ibin]
    zc = 0.5 * (zmin + zmax)
    sig_z = SIGZ_REL[isamp] * (1.0 + zc)
    sig_chi = C_KMS * sig_z / Hz_kms(zc) * survey.H  # Mpc/h
    return np.exp(-(k**2) * (sig_chi**2) / 6.0)


def sample_fisher(ibin, isamp, which, delta=None, damped=True,
                  N=300000, seed=0):
    eng = fisher.BinEngine(ibin)
    # override to single sample tracer
    nA = survey.NDENS[ibin][isamp]
    bA = survey.BIAS[ibin][isamp]
    eng.spec = dict(eng.spec)
    eng.spec["n_eff"], eng.spec["b_eff"] = nA, bA
    kg = eng._kg
    if damped:
        D = damping_D(ibin, isamp, kg)
    else:
        D = np.ones_like(kg)
    # damped transfer for the bispectrum signal: M -> M*D
    eng._lM = np.log(eng._M * D)
    # damped galaxy power for the variance: Pg = b^2 D^2 Pm + 1/n
    eng._lPg = np.log(bA**2 * D**2 * eng._Pm + 1.0 / nA)
    F, Ferr = fisher.fisher_mc(eng, which, delta=delta, N=N, seed=seed)
    return F, Ferr


def damping_penalty(which, delta=None, N=200000, seed=900):
    ratios = []
    for ibin in range(6):
        Fd = Fu = 0.0
        for isamp in range(5):
            f1, _ = sample_fisher(ibin, isamp, which, delta,
                                  damped=True, N=N,
                                  seed=seed + 10 * ibin + isamp)
            f0, _ = sample_fisher(ibin, isamp, which, delta,
                                  damped=False, N=N,
                                  seed=seed + 10 * ibin + isamp)
            Fd += f1
            Fu += f0
        r = np.sqrt(Fu / Fd)
        ratios.append(r)
        print(f"  bin {ibin}: damping penalty = {r:.3f}x", flush=True)
    return ratios


if __name__ == "__main__":
    print("LOCAL:")
    rl = damping_penalty("local")
    print("FLAT d=0.05:")
    rf = damping_penalty("flat", delta=0.05)
    print("mean local:", np.mean(rl), "mean flat:", np.mean(rf))
