"""
Fisher integrator for the single-tracer real-space tree-level galaxy
bispectrum. Independent implementation: Monte Carlo importance-sampled
triangle integral as the primary engine, plus a coarse regular-grid
labeled-sum as a cross-check.

Derived Fisher formula (single parameter p, fiducial p=0):
    F = V/(8 pi^4) * int dk1 dk2 dk3  Theta_tri * k1 k2 k3
        * (dB_g/dp)^2 / (P_g1 P_g2 P_g3)
with B_g = b1^3 M1 M2 M3 B_zeta,  P_gi = b1^2 P_m(ki) + 1/n,
M(k,z) = sqrt(P_m(k,z)/P_zeta(k)).

Derivation sketch (see REDO.md): labeled triangle count in bins of width
dk is N_lab = V^2 k1k2k3 dk^3/(8 pi^4); Gaussian variance of the binned
bispectrum estimator Var = s123 * V * P1 P2 P3 / N_lab with s123 = 6/2/1
for equal/all-distinct bin indices; the continuum limit gives the integral
above (coincidences are measure-zero).
"""
import numpy as np

import survey
import templates

_TWO_PI4 = 8.0 * np.pi**4


class BinEngine:
    """Per-z-bin precomputed quantities on a fine k-grid."""

    def __init__(self, ibin, nk=2500):
        self.spec = survey.bin_specs(ibin)
        self.cp = survey.get_cosmo()
        s = self.spec
        self.kmin, self.kmax = s["kmin"], s["kmax"]
        # log-spaced fine grid for Pm, M, Pzeta, Pg
        self._kg = np.exp(np.linspace(np.log(self.kmin), np.log(self.kmax), nk))
        z = s["zmid"]
        Pm = self.cp.Pm(z, self._kg)
        Pz = self.cp.Pzeta(self._kg)
        self._Pm = Pm
        self._M = np.sqrt(Pm / Pz)
        self._Pz = Pz
        b1, n = s["b_eff"], s["n_eff"]
        self._Pg = b1**2 * Pm + 1.0 / n
        self._lk = np.log(self._kg)
        self._lPm = np.log(Pm)
        self._lM = np.log(self._M)
        self._lPz = np.log(Pz)
        self._lPg = np.log(self._Pg)

    def _interp(self, lk, lval, k):
        return np.exp(np.interp(np.log(k), lk, lval,
                                left=lval[0], right=lval[-1]))

    def Pm(self, k):
        return self._interp(self._lk, self._lPm, k)

    def M(self, k):
        return self._interp(self._lk, self._lM, k)

    def Pzeta(self, k):
        return self._interp(self._lk, self._lPz, k)

    def Pg(self, k):
        return self._interp(self._lk, self._lPg, k)

    def dBg_local(self, k1, k2, k3):
        """dB_g/d(fNL^local) at fiducial 0: b1^3 M1M2M3 * dB_zeta/dfNL."""
        b1 = self.spec["b_eff"]
        dBz = templates.Bzeta_local(k1, k2, k3, self.Pzeta, fNL=1.0)
        return b1**3 * self.M(k1) * self.M(k2) * self.M(k3) * dBz

    def dBg_flat(self, k1, k2, k3, delta):
        b1 = self.spec["b_eff"]
        As = survey.COSMO["As"]
        dBz = templates.Bzeta_flat(k1, k2, k3, As, delta, fNL=1.0)
        return b1**3 * self.M(k1) * self.M(k2) * self.M(k3) * dBz


def _sample_triangles_mc(eng, N, delta=None, seed=0, pi_unif=0.5):
    """Draw N triangle configs with fold-concentrated importance sampling.

    Returns (k1, k2, k3, jac_over_q) with the MC weight factor
    (kmax-kmin)^2 * (k1+k2)/q(g) folded in as `w0` (without V/8pi^4).
    Invalid (non-triangle) draws get w0 = 0.
    """
    rng = np.random.default_rng(seed)
    kmin, kmax = eng.kmin, eng.kmax
    k1 = rng.uniform(kmin, kmax, N)
    k2 = rng.uniform(kmin, kmax, N)
    klo = np.maximum(kmin, np.abs(k1 - k2))
    khi = np.minimum(kmax, k1 + k2)
    valid = khi > klo
    ssum = k1 + k2
    g_lo = (ssum - khi) / ssum
    g_hi = (ssum - klo) / ssum
    # exponential scale: resolve the fold layer ~delta, floor at 0.01
    s_exp = max(delta if delta else 0.0, 0.01)
    u = rng.uniform(0.0, 1.0, N)
    g = np.empty(N)
    q = np.empty(N)
    # component A: uniform in [g_lo, g_hi]
    mA = u < pi_unif
    width = g_hi - g_lo
    g[mA] = g_lo[mA] + rng.uniform(0.0, 1.0, mA.sum()) * width[mA]
    # component B: truncated exponential from g_lo
    mB = ~mA
    widthB = np.maximum(g_hi - g_lo, 0.0)
    truncB = np.maximum(1.0 - np.exp(-widthB / s_exp), 1e-300)
    e = rng.uniform(0.0, 1.0, N)
    g[mB] = g_lo[mB] - s_exp * np.log1p(-e[mB] * truncB[mB])
    qA = pi_unif / np.maximum(width, 1e-300)
    qB = (1.0 - pi_unif) * np.exp(-(g - g_lo) / s_exp) / (s_exp * truncB)
    q = qA + qB
    k3 = (1.0 - g) * ssum
    w0 = np.zeros(N)
    w0[valid] = (kmax - kmin) ** 2 * ssum[valid] / q[valid]
    return k1, k2, k3, w0


def fisher_mc(eng, which, delta=None, N=300000, seed=0, nbatches=20,
              pi_unif=0.5):
    """Single-parameter Fisher via MC. `which` in {'local','flat'}."""
    k1, k2, k3, w0 = _sample_triangles_mc(eng, N, delta=delta, seed=seed,
                                          pi_unif=pi_unif)
    ok = w0 > 0
    k1, k2, k3, w0 = k1[ok], k2[ok], k3[ok], w0[ok]
    if which == "local":
        dB = eng.dBg_local(k1, k2, k3)
    elif which == "flat":
        dB = eng.dBg_flat(k1, k2, k3, delta)
    else:
        raise ValueError(which)
    integ = w0 * k1 * k2 * k3 * dB**2 / (eng.Pg(k1) * eng.Pg(k2) * eng.Pg(k3))
    V = eng.spec["V"]
    # MC estimate: F = V/(8pi^4) * mean(integ); batch means for the error.
    # The MC integrates over the FULL LABELED CUBE (all 6 permutations of
    # each scalene triangle); the continuum Fisher is over UNIQUE triangles,
    # so divide by 6 (non-scalene sets are measure-zero).
    ntot = len(integ)
    idx = np.array_split(np.arange(ntot), nbatches)
    bmeans = np.array([integ[i].mean() for i in idx])
    est = V / _TWO_PI4 / 6.0 * bmeans.mean()
    err = V / _TWO_PI4 / 6.0 * bmeans.std(ddof=1) / np.sqrt(nbatches)
    return est, err


def fisher_grid(eng, which, delta=None, Nk=36):
    """Coarse regular-grid labeled-sum cross-check (local only is smooth)."""
    kmin, kmax = eng.kmin, eng.kmax
    dk = (kmax - kmin) / Nk
    kc = kmin + (np.arange(Nk) + 0.5) * dk
    K1, K2, K3 = np.meshgrid(kc, kc, kc, indexing="ij")
    K1, K2, K3 = K1.ravel(), K2.ravel(), K3.ravel()
    tri = (K1 + K2 > K3) & (K1 + K3 > K2) & (K2 + K3 > K1)
    K1, K2, K3 = K1[tri], K2[tri], K3[tri]
    if which == "local":
        dB = eng.dBg_local(K1, K2, K3)
    elif which == "flat":
        dB = eng.dBg_flat(K1, K2, K3, delta)
    else:
        raise ValueError(which)
    # s123 from bin-index coincidences (recompute indices)
    i1 = np.clip(((K1 - kmin) / dk).astype(int), 0, Nk - 1)
    i2 = np.clip(((K2 - kmin) / dk).astype(int), 0, Nk - 1)
    i3 = np.clip(((K3 - kmin) / dk).astype(int), 0, Nk - 1)
    neq = (i1 == i2).astype(int) + (i2 == i3).astype(int) + (i1 == i3).astype(int)
    s123 = np.where(neq == 3, 6.0, np.where(neq == 1, 2.0, 1.0))
    V = eng.spec["V"]
    # Full-cube sum: divide by 6 for unique triangles (s123 kept only as a
    # reminder of the bin-coincidence structure; it is 1 a.e.).
    contrib = dB**2 * V * K1 * K2 * K3 * dk**3 / (
        _TWO_PI4 * 6.0 * eng.Pg(K1) * eng.Pg(K2) * eng.Pg(K3))
    return contrib.sum()
