"""
SPHEREx-like survey model for the independent Fisher redo.

All survey numbers are taken from Heinrich et al., arXiv:2311.13082
("Measuring f_NL with the SPHEREx Multi-tracer Redshift Space Bispectrum"),
Appendix tables: 11 redshift bins, 5 galaxy samples split by redshift
uncertainty. We use the first six bins (0 < z < 1.6), which the paper shows
dominate the bispectrum f_NL constraint (higher-z bins contribute negligibly).

Independent choices vs the original forecast (which used 3 coarse z-bins
0.2-0.6/0.6-1.0/1.0-1.6 with assumed specs and k_max=0.2 h/Mpc flat):
  - 6 published redshift bins with the published per-sample n(z), b(z)
  - k_max = 0.2*(1+z) h/Mpc (the paper's conservative linear-regime cut)
  - k_min = 2*pi/V^{1/3} per bin (the paper's fundamental-mode estimate)
  - effective single tracer per z-bin: n_eff = sum_A n_A,
    b_eff = sum_A n_A b_A / sum_A n_A  (disjoint samples, one effective tracer)
  - real-space, tree-level, angle-averaged (no RSD, no photo-z damping,
    no multitracer cross-spectra, no power-spectrum info) -- all documented
    as known omissions in REDO.md
"""
import numpy as np

# --- redshift bins (zmin, zmax), first six of 2311.13082 Table 1 ---
Z_BINS = [
    (0.0, 0.2),
    (0.2, 0.4),
    (0.4, 0.6),
    (0.6, 0.8),
    (0.8, 1.0),
    (1.0, 1.6),
]

# --- fiducial linear bias b10, 5 samples x 6 bins (Table 2 of 2311.13082) ---
# rows = z-bins 1..6, cols = samples 1..5 (sigma_z/(1+z) = 0.003..0.2)
BIAS = np.array([
    [1.3, 1.2, 1.0, 0.98, 0.83],
    [1.5, 1.4, 1.3, 1.3,  1.2 ],
    [1.8, 1.6, 1.5, 1.4,  1.3 ],
    [2.3, 1.9, 1.7, 1.5,  1.4 ],
    [2.1, 2.3, 1.9, 1.7,  1.6 ],
    [2.7, 2.6, 2.6, 2.2,  2.1 ],
])

# --- galaxy number density [(h/Mpc)^3], 5 samples x 6 bins (Table 3) ---
NDENS = np.array([
    [9.97e-3, 1.23e-2, 1.34e-2, 2.29e-2, 1.49e-2],
    [4.11e-3, 8.56e-3, 8.57e-3, 1.29e-2, 7.52e-3],
    [5.01e-4, 2.82e-3, 3.62e-3, 5.35e-3, 3.27e-3],
    [7.05e-5, 9.37e-4, 2.94e-3, 4.95e-3, 2.50e-3],
    [3.16e-5, 4.30e-4, 2.04e-3, 4.15e-3, 1.83e-3],
    [1.64e-5, 5.00e-5, 2.12e-4, 7.96e-4, 7.34e-4],
])

F_SKY = 0.75  # all-sky minus galactic mask (Doré et al. 2014; 2311.13082)

# --- fiducial cosmology: Planck 2018 as in 2311.13082 Sec. IV ---
COSMO = dict(
    H0=67.36, ombh2=0.02238, omch2=0.1201,
    As=2.1e-9, ns=0.9659, nrun=0.0, k_pivot=0.05,
)
H = COSMO["H0"] / 100.0  # h


class CosmoPower:
    """Linear matter power + background via CAMB. k in h/Mpc, P in (Mpc/h)^3."""

    def __init__(self):
        import camb
        c = COSMO
        pars = camb.CAMBparams()
        pars.set_cosmology(H0=c["H0"], ombh2=c["ombh2"], omch2=c["omch2"])
        pars.InitPower.set_params(As=c["As"], ns=c["ns"], nrun=c["nrun"])
        zmax = 1.7
        pars.set_matter_power(redshifts=np.linspace(0.0, zmax, 18).tolist(),
                              kmax=2.0)
        self._res = camb.get_results(pars)
        self._pk = camb.get_matter_power_interpolator(
            pars, nonlinear=False, hubble_units=True, k_hunit=True)
        # k_hunit=True, hubble_units=True -> k in h/Mpc, P in (Mpc/h)^3
        self._zgrid = np.linspace(0.0, zmax, 18)

    def Pm(self, z, kh):
        kh = np.asarray(kh, dtype=float)
        return self._pk.P(z, kh, grid=False)

    def chi(self, z):
        """Comoving radial distance in Mpc/h."""
        return np.asarray(self._res.comoving_radial_distance(z)) * H

    def Pzeta(self, kh):
        """Primordial curvature power, (Mpc/h)^3. k in h/Mpc."""
        c = COSMO
        kh = np.asarray(kh, dtype=float)
        return 2.0 * np.pi**2 * c["As"] / kh**3 * (kh / c["k_pivot"])**(c["ns"] - 1.0)

    def Mtrans(self, z, kh):
        """Poisson transfer delta = M*zeta, via sqrt(Pm/Pzeta)."""
        return np.sqrt(self.Pm(z, kh) / self.Pzeta(kh))


def bin_volume(zmin, zmax):
    """Comoving survey volume of a z-bin in (Mpc/h)^3."""
    cp = _CP
    chi_max = cp.chi(zmax)
    chi_min = cp.chi(zmin)
    return F_SKY * 4.0 * np.pi / 3.0 * (chi_max**3 - chi_min**3)


_CP = None

def get_cosmo():
    global _CP
    if _CP is None:
        _CP = CosmoPower()
    return _CP


def effective_tracer(ibin):
    """Effective single tracer for z-bin ibin: n_eff, b_eff."""
    n = NDENS[ibin]
    b = BIAS[ibin]
    n_eff = n.sum()
    b_eff = (n * b).sum() / n_eff
    return n_eff, b_eff


def bin_specs(ibin):
    """Return dict with everything the Fisher needs for z-bin ibin."""
    cp = get_cosmo()
    zmin, zmax = Z_BINS[ibin]
    zmid = 0.5 * (zmin + zmax)
    V = bin_volume(zmin, zmax)
    kmin = 2.0 * np.pi / V**(1.0 / 3.0)   # fundamental mode (h/Mpc)
    kmax = 0.2 * (1.0 + zmid)              # 2311.13082 conservative cut
    n_eff, b_eff = effective_tracer(ibin)
    return dict(ibin=ibin, zmin=zmin, zmax=zmax, zmid=zmid, V=V,
                kmin=kmin, kmax=kmax, n_eff=n_eff, b_eff=b_eff)
