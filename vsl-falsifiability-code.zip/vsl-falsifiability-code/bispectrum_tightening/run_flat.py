"""Flattened-shape Fisher: sigma(f_NL^flat) vs regulator delta.

Primary result: single-parameter Fisher, effective single tracer per z-bin,
real-space tree-level, MC importance-sampled triangle integral.
Template normalization validated against the paper's Eq. 6.9 (templates.py).
"""
import json
import time
import numpy as np

import fisher
import survey

DELTAS = [0.10, 0.05, 0.02, 0.01]


def run_flat(deltas=DELTAS, N=600000, seed=1000):
    engines = [fisher.BinEngine(ibin) for ibin in range(6)]
    out = {}
    for delta in deltas:
        Ftot = 0.0
        err2 = 0.0
        per_bin_sig = []
        for ibin, eng in enumerate(engines):
            t0 = time.time()
            F, Ferr = fisher.fisher_mc(eng, "flat", delta=delta, N=N,
                                       seed=seed + int(delta * 1e4) + ibin)
            Ftot += F
            err2 += Ferr**2
            per_bin_sig.append(1.0 / np.sqrt(F))
            print(f"  delta={delta} bin {ibin}: sigma={1/np.sqrt(F):.4f} "
                  f"({time.time()-t0:.1f}s)", flush=True)
        sig = 1.0 / np.sqrt(Ftot)
        sig_err = 0.5 * np.sqrt(err2) / Ftot**1.5
        out[str(delta)] = dict(sigma=sig, sigma_err=sig_err,
                               significance=1.0 / sig,
                               per_bin_sigma=per_bin_sig)
        print(f"DELTA={delta}: sigma(fNL^flat) = {sig:.4f} +- {sig_err:.4f} "
              f"-> {1/sig:.1f} sigma", flush=True)
    return out


if __name__ == "__main__":
    out = run_flat()
    with open("../results/flat_fisher.json", "w") as f:
        json.dump(out, f, indent=2)
    print("wrote ../results/flat_fisher.json")
