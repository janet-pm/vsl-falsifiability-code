"""
Two-tracer multitracer bispectrum Fisher (diagnostic).

Measures the multitracer gain over a single effective tracer WITHIN our
own pipeline, for the local and flattened shapes.

Setup: 2 tracers (A,B) in one z-bin. Data vector per triangle:
  B^{XYZ}(k1,k2,k3), X,Y,Z in {A,B}  (8 combos)
Gaussian covariance (Wick):
  Cov(B^{XYZ}, B^{X'Y'Z'}) = (1/N_tri) * sum over 6 leg-pairings
      P^{x1 x1'}(k1) P^{x2 x2'}(k2) P^{x3 x3'}(k3)
  P^{XY}(k) = b_X b_Y P_m(k) + delta_{XY}/n_X.
Signal: dB^{XYZ}/dfNL = b_X b_Y b_Z M1M2M3 dB_zeta/dfNL.
F = sum_tri dB_vec^T C^{-1} dB_vec ; continuum MC as in fisher.py.

Comparison: single effective tracer with n_eff = n_A+n_B,
b_eff = (n_A b_A + n_B b_B)/(n_A+n_B).
"""
import itertools
import numpy as np

import fisher
import survey
import templates


class TwoTracerEngine:
    def __init__(self, ibin, ia=0, ib=1):
        self.base = fisher.BinEngine(ibin)
        self.spec = self.base.spec
        self.kmin, self.kmax = self.base.kmin, self.base.kmax
        n = survey.NDENS[ibin]
        b = survey.BIAS[ibin]
        self.nA, self.nB = n[ia], n[ib]
        self.bA, self.bB = b[ia], b[ib]
        # effective single tracer for comparison
        self.n_eff = self.nA + self.nB
        self.b_eff = (self.nA * self.bA + self.nB * self.bB) / self.n_eff

    def Pxy(self, X, Y, k):
        bX = self.bA if X == 0 else self.bB
        bY = self.bA if Y == 0 else self.bB
        Pm = self.base.Pm(k)
        shot = 0.0 if X != Y else 1.0 / (self.nA if X == 0 else self.nB)
        return bX * bY * Pm + shot

    def dB_vec(self, k1, k2, k3, which, delta=None):
        M1, M2, M3 = self.base.M(k1), self.base.M(k2), self.base.M(k3)
        if which == "local":
            dBz = templates.Bzeta_local(k1, k2, k3, self.base.Pzeta, fNL=1.0)
        else:
            dBz = templates.Bzeta_flat(k1, k2, k3, survey.COSMO["As"],
                                       delta, fNL=1.0)
        pre = M1 * M2 * M3 * dBz
        bvec = np.array([self.bA, self.bB])
        out = np.empty((8,) + np.shape(k1))
        for i, (X, Y, Z) in enumerate(itertools.product([0, 1], repeat=3)):
            out[i] = bvec[X] * bvec[Y] * bvec[Z] * pre
        return out  # (8, N)

    def fisher_2tr(self, which, delta=None, N=200000, seed=0):
        k1, k2, k3, w0 = fisher._sample_triangles_mc(
            self.base, N, delta=delta, seed=seed)
        ok = w0 > 0
        k1, k2, k3, w0 = k1[ok], k2[ok], k3[ok], w0[ok]
        n = len(k1)
        dB = self.dB_vec(k1, k2, k3, which, delta)          # (8, n)
        combos = list(itertools.product([0, 1], repeat=3))
        # covariance per triangle: C[(X,Y,Z),(Xp,Yp,Zp)]
        F = 0.0
        # process in chunks for memory
        chunk = 20000
        for s in range(0, n, chunk):
            e = min(s + chunk, n)
            m = e - s
            C = np.zeros((m, 8, 8))
            P1 = np.array([[self.Pxy(X, Xp, k1[s:e]) for Xp in [0, 1]]
                           for X in [0, 1]])  # (2,2,m)
            P2 = np.array([[self.Pxy(Y, Yp, k2[s:e]) for Yp in [0, 1]]
                           for Y in [0, 1]])
            P3 = np.array([[self.Pxy(Z, Zp, k3[s:e]) for Zp in [0, 1]]
                           for Z in [0, 1]])
            for i, (X, Y, Z) in enumerate(combos):
                for j, (Xp, Yp, Zp) in enumerate(combos):
                    # Continuum (generic scalene) triangles: only the identity
                    # Wick pairing survives; the other 5 pairings require bin
                    # coincidences (measure-zero). This is a Kronecker
                    # product of 2x2 PD blocks, hence PD.
                    C[:, i, j] = P1[X, Xp] * P2[Y, Yp] * P3[Z, Zp]
            # solve C x = dB per triangle: F += dB^T C^{-1} dB * weight
            dBc = dB[:, s:e].T                       # (m, 8)
            w = w0[s:e] * k1[s:e] * k2[s:e] * k3[s:e]
            L = np.linalg.cholesky(C)
            y = np.linalg.solve(L, dBc[:, :, None])
            x = np.linalg.solve(L.transpose(0, 2, 1), y)
            F += np.sum((dBc[:, :, None] * x).sum(axis=1).squeeze(-1) * w)
        F *= self.spec["V"] / fisher._TWO_PI4 / n * len(k1) / len(k1)
        # NOTE: MC mean normalization: F = V/8pi^4 * mean(w * dB^T C^-1 dB).
        # Full labeled cube -> unique triangles: divide by 6.
        return F / 6.0

    def fisher_eff(self, which, delta=None, N=200000, seed=0):
        """Single effective tracer (nA+nB, n-weighted bias) for comparison."""
        eng = self.base
        # temporarily override tracer
        old_n, old_b = eng.spec["n_eff"], eng.spec["b_eff"]
        eng.spec = dict(eng.spec)
        eng.spec["n_eff"], eng.spec["b_eff"] = self.n_eff, self.b_eff
        b1 = self.b_eff
        eng._Pg = b1**2 * eng._Pm + 1.0 / self.n_eff
        eng._lPg = np.log(eng._Pg)
        F, _ = fisher.fisher_mc(eng, which, delta=delta, N=N, seed=seed)
        eng.spec["n_eff"], eng.spec["b_eff"] = old_n, old_b
        eng._Pg = old_b**2 * eng._Pm + 1.0 / old_n
        eng._lPg = np.log(eng._Pg)
        return F


if __name__ == "__main__":
    import time
    for which, delta in [("local", None), ("flat", 0.05)]:
        print(f"=== {which} delta={delta} ===")
        for ibin in [2, 5]:
            t0 = time.time()
            te = TwoTracerEngine(ibin, 0, 1)
            F2 = te.fisher_2tr(which, delta=delta, N=120000, seed=400 + ibin)
            Fe = te.fisher_eff(which, delta=delta, N=120000, seed=400 + ibin)
            print(f"  bin {ibin}: 2-tracer sig={1/np.sqrt(F2):.3f} | "
                  f"eff-tracer sig={1/np.sqrt(Fe):.3f} | "
                  f"gain={np.sqrt(Fe/F2):.2f}x ({time.time()-t0:.0f}s)",
                  flush=True)
