"""
r null test: Afshordi & Magueijo (2016) VSL "critical geometry" predicts r = 0
(zero primordial gravitational waves) AND n_s = 0.96478.

Data: Planck 2018 (high-l TTTEEE lite + low-l TT + low-l EE) + BICEP/Keck BK18
(B-mode only, 9 ell bins, with Planck/WMAP maps for foregrounds).

Fits (Powell minimizer, all other params re-optimized):
  A: ns free, r free              -> chi2_A
  B: ns free, r = 0               -> chi2_B ; dchi2_r = chi2_B - chi2_A (1 dof)
  C: ns = 0.96478, r = 0  (VSL)   -> chi2_C ; dchi2_joint (2 dof)

Varied: 6 LCDM + r + BBdust, BBsync, BBbetadust, BBbetasync.
Fixed: BBalphadust=-0.42, BBalphasync=-0.6, BBdustsynccorr=0, A_planck=1,
       BK18 internal defaults (EEtoBB=2, Td=19.6, delta=1, gammas=0).
Gaussian prior N(-3.1, 0.3) on BBbetasync included as chi2 penalty
(BK18 baseline analysis choice).
Hard prior bounds enforced as walls (return 1e9 outside).
"""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize
from scipy.stats import chi2 as chi2_dist

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model

NS_VSL = 0.96478

# Start from the Planck-only best fit of the n_s null test (results/null_test_free.json)
START = {
    "ombh2": 0.0223869, "omch2": 0.120157, "cosmomc_theta": 0.0104088,
    "tau": 0.054357, "As": 2.0984e-09, "ns": 0.9648287,
    "r": 0.015,
    "BBdust": 4.4, "BBsync": 1.0, "BBbetadust": 1.59, "BBbetasync": -3.1,
}
PARAM_ORDER = ["ombh2", "omch2", "cosmomc_theta", "tau", "As", "ns", "r",
               "BBdust", "BBsync", "BBbetadust", "BBbetasync"]
SCALE = {"ombh2": 100.0, "omch2": 100.0, "cosmomc_theta": 1000.0,
         "tau": 100.0, "As": 1e9, "ns": 1.0, "r": 100.0,
         "BBdust": 1.0, "BBsync": 1.0, "BBbetadust": 10.0, "BBbetasync": 1.0}
BOUNDS = {"ombh2": (0.018, 0.028), "omch2": (0.08, 0.16),
          "cosmomc_theta": (0.0103, 0.0105), "tau": (0.02, 0.12),
          "As": (1.5e-9, 2.8e-9), "ns": (0.90, 1.05), "r": (0.0, 0.5),
          "BBdust": (0.0, 15.0), "BBsync": (0.0, 50.0),
          "BBbetadust": (0.80, 2.40), "BBbetasync": (-6.0, 0.0)}


def build_model():
    info = {
        "params": {
            "ombh2": {"prior": [0.018, 0.028]},
            "omch2": {"prior": [0.08, 0.16]},
            "cosmomc_theta": {"prior": [0.0103, 0.0105]},
            "tau": {"prior": [0.02, 0.12]},
            "As": {"prior": [1.5e-9, 2.8e-9]},
            "ns": {"prior": [0.90, 1.05]},
            "r": {"prior": [0.0, 0.5]},
            "BBdust": {"prior": [0.0, 15.0]},
            "BBsync": {"prior": [0.0, 50.0]},
            "BBbetadust": {"prior": [0.80, 2.40]},
            "BBbetasync": {"prior": [-6.0, 0.0]},
            "BBalphadust": -0.42,
            "BBalphasync": -0.6,
            "BBdustsynccorr": 0.0,
            "A_planck": 1,
        },
        "theory": {"camb": {"extra_args": {"lmax": 2700}}},
        "likelihood": {
            "planck_2018_highl_plik.TTTEEE_lite": None,
            "planck_2018_lowl.TT": None,
            "planck_2018_lowl.EE": None,
            "bicep_keck_2018": None,
        },
    }
    return get_model(info)


MODEL = None
N_EVAL = 0


def chi2_of(scaled_vec, order, fixed):
    """-2 ln L (+ Gaussian prior penalty on BBbetasync) for scaled vector.
    order: varied param names; fixed: dict of fixed param values."""
    global N_EVAL
    params = {}
    for n, s in zip(order, scaled_vec):
        v = float(s) / SCALE[n]
        lo, hi = BOUNDS[n]
        if not (lo <= v <= hi):
            return 1e9
        params[n] = v
    params.update(fixed)
    N_EVAL += 1
    try:
        out = MODEL.loglikes(params)
        c2 = float(out[1][0])
        if not np.isfinite(c2):
            return 1e9
        # BK18 baseline Gaussian prior on synchrotron spectral index
        c2 += ((params["BBbetasync"] + 3.1) / 0.3) ** 2
        return c2
    except Exception:
        return 1e9


def run_fit(label, order, fixed, x0_dict, maxiter=40):
    global N_EVAL
    N_EVAL = 0
    t_start = time.time()
    x0 = np.array([x0_dict[n] * SCALE[n] for n in order])
    best_so_far = [1e18]

    def f(v):
        c2 = chi2_of(v, order, fixed)
        if c2 < best_so_far[0]:
            best_so_far[0] = c2
        if N_EVAL % 25 == 0:
            print(f"[{label}] eval {N_EVAL}: chi2={c2:.3f} "
                  f"best={best_so_far[0]:.3f}", flush=True)
        return c2

    res = minimize(f, x0, method="Powell",
                   options={"maxiter": maxiter, "xtol": 1e-4, "ftol": 0.1,
                            "disp": False})
    dt = time.time() - t_start
    best = {n: (float(res.x[order.index(n)]) / SCALE[n] if n in order
                else fixed.get(n)) for n in PARAM_ORDER}
    print(f"[{label}] chi2 = {res.fun:.3f}  evals = {N_EVAL}  "
          f"time = {dt:.0f}s", flush=True)
    print(f"[{label}] best-fit: " +
          " ".join(f"{k}={v:.6g}" for k, v in best.items()), flush=True)
    return {"label": label, "chi2": float(res.fun), "best_fit": best,
            "evals": N_EVAL, "seconds": dt}


def main():
    global MODEL
    print("Building Cobaya model (CAMB + Planck lite + BK18)...", flush=True)
    MODEL = build_model()

    # Sanity: CAMB tensors must respond to r (BK18 BB chi2 should move with r)
    v0 = np.array([START[n] * SCALE[n] for n in PARAM_ORDER])
    order_nor = [n for n in PARAM_ORDER if n != "r"]
    v_nor = np.array([START[n] * SCALE[n] for n in order_nor])
    c_r0 = chi2_of(v_nor, order_nor, {"r": 0.0})
    c_r5 = chi2_of(v_nor, order_nor, {"r": 0.05})
    print(f"[sanity] chi2(r=0)={c_r0:.3f} chi2(r=0.05)={c_r5:.3f} "
          f"(must differ -> tensors active)", flush=True)

    ckpt = "/home/hatch/workspace/vsl-planck/bicep-r/results/r_null_test_ckpt.json"
    results = {}

    # Fit A: r free, ns free
    order_a = PARAM_ORDER
    a = run_fit("A-r-free", order_a, {}, START)
    results["fit_A_r_free"] = a
    with open(ckpt, "w") as f:
        json.dump(results, f, indent=2)
    print("Checkpoint A saved.", flush=True)

    # Fit B: r = 0, ns free (isolates the r leg)
    order_b = [n for n in PARAM_ORDER if n != "r"]
    b = run_fit("B-r0", order_b, {"r": 0.0}, a["best_fit"])
    results["fit_B_r0"] = b
    with open(ckpt, "w") as f:
        json.dump(results, f, indent=2)
    print("Checkpoint B saved.", flush=True)

    # Fit C: joint VSL (ns = 0.96478, r = 0)
    order_c = [n for n in PARAM_ORDER if n not in ("r", "ns")]
    c = run_fit("C-vsl-joint", order_c,
                {"r": 0.0, "ns": NS_VSL}, b["best_fit"])
    results["fit_C_vsl_joint"] = c
    with open(ckpt, "w") as f:
        json.dump(results, f, indent=2)
    print("Checkpoint C saved.", flush=True)

    # Profile points for the 95% upper limit on r (one-sided: Delta chi2 = 2.71)
    prof = {}
    for rfix in [0.02, 0.036, 0.06]:
        p = run_fit(f"P-r{rfix}", order_b, {"r": rfix}, a["best_fit"],
                    maxiter=30)
        prof[str(rfix)] = p
        results[f"profile_r_{rfix}"] = p
        with open(ckpt, "w") as f:
            json.dump(results, f, indent=2)
        print(f"Checkpoint profile r={rfix} saved.", flush=True)

    dchi2_r = b["chi2"] - a["chi2"]
    dchi2_joint = c["chi2"] - a["chi2"]
    p_r = float(chi2_dist.sf(max(dchi2_r, 0), 1))
    p_joint = float(chi2_dist.sf(max(dchi2_joint, 0), 2))

    out = {
        "prediction": {"model": "Afshordi & Magueijo 2016 VSL critical geometry",
                       "ns_vsl": NS_VSL, "r_vsl": 0.0},
        "data": ("Planck 2018 high-l TTTEEE lite + low-l TT + low-l EE + "
                 "BICEP/Keck BK18 B-modes"),
        "fits": {"A_r_free": a, "B_r0": b, "C_vsl_joint": c},
        "profile": prof,
        "delta_chi2_r_leg_1dof": float(dchi2_r),
        "p_value_r_leg": p_r,
        "delta_chi2_joint_2dof": float(dchi2_joint),
        "p_value_joint": p_joint,
        "notes": (
            "Varied: 6 LCDM + r + BBdust, BBsync, BBbetadust, BBbetasync. "
            "Fixed: BBalphadust=-0.42, BBalphasync=-0.6, BBdustsynccorr=0, "
            "A_planck=1, BK18 internal defaults. Gaussian prior N(-3.1,0.3) "
            "on BBbetasync included (BK18 baseline). Minimizer: Powell. "
            "First pass, not a publication."),
    }
    with open("/home/hatch/workspace/vsl-planck/bicep-r/results/r_null_test.json",
              "w") as f:
        json.dump(out, f, indent=2)
    print("\n==== RESULT ====", flush=True)
    print(f"chi2 A (r free)        : {a['chi2']:.3f}  r_best={a['best_fit']['r']:.5f}",
          flush=True)
    print(f"chi2 B (r=0)           : {b['chi2']:.3f}", flush=True)
    print(f"chi2 C (VSL joint)     : {c['chi2']:.3f}", flush=True)
    print(f"Delta chi2 r-leg (1dof): {dchi2_r:.3f}   p = {p_r:.3f}", flush=True)
    print(f"Delta chi2 joint (2dof): {dchi2_joint:.3f}   p = {p_joint:.3f}", flush=True)
    for k, p in prof.items():
        print(f"profile r={k}: chi2={p['chi2']:.3f} "
              f"dchi2={p['chi2']-a['chi2']:.3f}", flush=True)


if __name__ == "__main__":
    main()
