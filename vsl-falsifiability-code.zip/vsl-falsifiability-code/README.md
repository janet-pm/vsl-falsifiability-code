# Analysis code for "A dataset-dependent falsifiability analysis of the Afshordi–Magueijo critical-geometry varying-speed-of-light cosmology"

This bundle contains the project-written analysis scripts behind the paper's
headline numerical results. The scripts reproduce:

- the Planck PR3 null test of the n_s = 0.96478 prediction (free fit
  n_s = 0.964777; fixing n_s = 0.96478 costs Δχ² = 0.001, ~0.03σ),
- the Planck PR3 + BK18 r null test (free r = 0.0105; fixing r = 0 costs
  Δχ² = 0.856, ~0.9σ),
- the ACT DR6 null tests (free n_s = 0.968018; fixing 0.96478 costs
  Δχ² = 3.63, ~1.9σ; the reheating variant 0.96838 costs Δχ² = 2.08,
  ~1.4σ),
- the (ε, F) knob-grid scan and inversion against published constraints
  (ε > 5.4 at F = 1; F < 3.8×10¹⁰ at ε → ∞ for Planck; F ~ 10^15.6 to
  reach the P-ACT-LB 1σ edge and ~10^27.7 for its central value),
- the SPHEREx flattened-bispectrum Fisher forecast and its independent
  tightening redo (raw single-parameter significance 1.4σ at regulator
  δ = 0.10 rising to ~10σ at δ = 0.01; bias marginalization degrades the
  flattened shape 2.14× versus 1.42× for local).

Likelihood data are NOT bundled (see "Data sources" below). Figure 1 of the
paper (`figure/ns_r_plane.pdf`) is included as an artifact; it was assembled
from published 1D constraints (the caption says the bands are not MCMC
contours), and its ad-hoc generating script was not retained.

## Layout and per-script guide

Run order for a full reproduction: `planck/` → `bk18/` → `act/` → `knobs/` →
`bispectrum_forecast/` → `bispectrum_tightening/`.

### planck/ — Planck PR3 null test
- `null_test.py` — Fits base ΛCDM to Planck 2018 (high-ℓ TT/TE/EE lite +
  low-ℓ TT Commander + low-ℓ EE SimAll) with n_s free and with n_s fixed to
  0.96478 (r = 0 in both). Powell minimizer via cobaya/CAMB.
  Runtime: tens of minutes on a workstation. Check: free n_s ≈ 0.964777,
  Δχ²(fixed − free) ≈ 0.001.
- `polish_free.py` — Re-polishes the free-n_s minimum starting from the
  fixed fit's best fit, so both minima are found to the same precision.

### bk18/ — Planck + BICEP/Keck 2018 r null test
- `r_null_test.py` — Adds the BK18 B-mode likelihood; fits (A) n_s and r
  free, (B) r = 0, (C) n_s = 0.96478 and r = 0. Powell minimizer.
  Runtime: tens of minutes. Check: free r ≈ 0.0105, Δχ²(B − A) ≈ 0.856.

### act/ — ACT DR6 null tests
- `act_null_test.py` — Main driver: official ACT DR6 CMB-only lite
  likelihood plus Planck low-ℓ EE; free fit (A), refined free fit (A2),
  fixed-n_s fits (B: 0.96478, C: 0.96838). Documents the reproduction
  caveats in its header (Powell convergence, a +2.58 log-likelihood offset
  in the repo's shipped self-test under our dependency versions).
  Runtime: up to a few hours. Check: free n_s ≈ 0.968018,
  Δχ²(B − A) ≈ 3.63, Δχ²(C − A) ≈ 2.08.
- `fit_A2.py` — Refined 7-parameter free fit (tighter Powell settings).
- `fit_BC.py` — Standalone fixed-n_s fits B and C, seeded from fit A.
- **Caveat (also in the paper's methods section):** the ACT result is a
  likelihood reproduction, not the collaboration's own chains; Powell
  convergence on the 7-parameter landscape is imperfect and our free fit
  sits ~1σ below the published ACT-alone value (0.973 ± 0.006). The exact
  significance is subject to these reproduction uncertainties.

### knobs/ — (ε, F) grid scan
- `knobs.py` — Exact tilt/running formulas: solves for the transition
  variable x, n_s(ε, F), α_s in the Eq. (55) and Eq. (63) forms.
- `scan.py` — 140×140 grid over ε ∈ [1, 10^6], F ∈ [1, 10^15]; inverts
  the grid against published dataset constraints. Runtime: minutes.
  Check against `knobs.json` / the paper: Planck requires ε > 5.4 (1σ) at
  F = 1 and allows F < 3.8×10¹⁰ (1σ) at ε → ∞; reaching the P-ACT-LB
  central value needs F ~ 10^27.7.
- `plot.py` — Regenerates the knob-report plots from `grid.npz`.
- `grid.npz`, `knobs.json` — Derived scan products (included so the plots
  and inversions can be remade without re-running the scan).

### bispectrum_forecast/ — original SPHEREx forecast
- `common.py` — Shared cosmology, primordial templates, CAMB interface.
- `cmb.py` — CMB bispectrum Fisher forecast (temperature only); local
  shape via exact separable line-of-sight integrals, flattened shape via
  Fourier decomposition of the folded kernel.
- `lss.py` — Galaxy-bispectrum Fisher forecast for primordial
  non-Gaussianity.
- `validate_eq69.py` — Validates the folded coefficient against Eq. 6.9
  of Mylova et al. (2112.08179).

### bispectrum_tightening/ — independent redo + realism corrections
- `run_flat.py` — Driver: flattened-shape Fisher significance vs regulator
  δ ∈ {0.10, 0.05, 0.02, 0.01}. Check against `results/redo.json`:
  1.4σ, 2.4σ, 5.4σ, 10.3σ.
- `fisher.py`, `inner_products.py`, `survey.py`, `templates.py` — Fisher
  machinery, SPHEREx survey definition, template normalization (validated
  against the 2022 paper's Eq. 6.9).
- `marginalize.py` — Bias-template marginalization: degrades flattened
  2.14× vs local 1.42×. `multitracer.py`, `photoz.py` — multitracer gain
  (≈1.00× for bispectrum-only) and photo-z damping diagnostics.
- `validate_local.py` — Reproduces the published SPHEREx σ(f_NL^local) as
  a pipeline sanity check (see `results/local_validation.json`).
- `results/` — Small derived JSON products of the redo.

### figure/
- `ns_r_plane.pdf` — Figure 1 of the paper (2D n_s–r plane with the model
  as a point, published 1D constraint bands, and forecast ellipses).
  Included as an artifact; the ad-hoc script that assembled it from
  published constraints was not retained.

## Dependencies

- Python 3.12 (other 3.10+ likely fine)
- numpy, scipy, matplotlib
- camb (tested with 2.0.4) — https://github.com/cmbant/CAMB
- cobaya (likelihood/minimizer framework) — https://cobaya.readthedocs.io
- sacc 2.4 (pulled in by the ACT DR6 likelihood install)
- The ACT DR6 CMB-only likelihood package itself (see Data sources)

No requirements.txt is provided because the likelihood codes are installed
via cobaya-install / the collaboration repos, which manage their own
dependencies.

## Data sources (not bundled)

- Planck 2018 likelihoods (plik_lite TT/TE/EE, Commander low-ℓ TT, SimAll
  low-ℓ EE): Planck Legacy Archive, https://pla.esac.esa.int/
- BICEP/Keck 2018 likelihood: https://bicepkeck.org/ (also installable via
  `cobaya-install`)
- ACT DR6 CMB-only lite likelihood: https://github.com/ACTCollaboration/dr6-cmbonly
  (data fetched from NASA LAMBDA via cobaya-install)
- CAMB: https://github.com/cmbant/CAMB

## Reproduction notes

The Planck and BK18 fits are the most straightforward to reproduce once the
likelihood data are installed. The ACT fits are the most fragile (see the
caveat above and `act/act_null_test.py` header). The knob scan and
bispectrum redo are pure-Python/numpy and should reproduce exactly given
the same package versions.

## Suggested citation

Schaefer, J. R. (2026). Analysis code for "A dataset-dependent
falsifiability analysis of the Afshordi–Magueijo critical-geometry
varying-speed-of-light cosmology". GitHub.
https://github.com/janet-pm/vsl-falsifiability-code
