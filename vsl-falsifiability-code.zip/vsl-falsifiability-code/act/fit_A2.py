"""Refined free fit (A2). Fit A (7-param Powell) stopped at chi2=553.001
but subsequent fixed-ns fits found lower chi2 (550.791), proving A had not
converged. This re-runs the free fit starting from the best known point
(fit C solution) with tighter settings."""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model  # noqa: E402

# Best known point: fit C solution (chi2=550.791), ns freed
START = {
    "ombh2": 0.0226539,
    "omch2": 0.120778,
    "cosmomc_theta": 0.0104068,
    "tau": 0.05393,
    "As": 2.10028e-09,
    "ns": 0.96838,
    "P_act": 1.00097,
}
PARAM_ORDER = ["ombh2", "omch2", "cosmomc_theta", "tau", "As", "ns", "P_act"]
SCALE = {"ombh2": 100.0, "omch2": 100.0, "cosmomc_theta": 1000.0,
         "tau": 100.0, "As": 1e9, "ns": 1.0, "P_act": 1.0}
CAMB_ARGS = {"lmax": 9000, "lens_potential_accuracy": 8,
             "min_l_logl_sampling": 6000}


def build_model():
    info = {
        "params": {
            "ombh2": {"prior": [0.018, 0.028]},
            "omch2": {"prior": [0.08, 0.16]},
            "cosmomc_theta": {"prior": [0.0103, 0.0105]},
            "tau": {"prior": [0.02, 0.12]},
            "As": {"prior": [1.5e-9, 2.8e-9]},
            "ns": {"prior": [0.90, 1.05]},
            "P_act": {"prior": [0.9, 1.1]},
            "r": 0,
        },
        "theory": {"camb": {"extra_args": CAMB_ARGS}},
        "likelihood": {
            "act_dr6_cmbonly": {
                "input_file": "dr6_data_cmbonly.fits",
                "params": {"A_act": 1.0},
            },
            "planck_2018_lowl.EE": None,
        },
    }
    return get_model(info)


MODEL = None
N_EVAL = 0


def chi2_of(scaled_vec):
    global N_EVAL
    params = {n: float(s) / SCALE[n] for n, s in zip(PARAM_ORDER, scaled_vec)}
    N_EVAL += 1
    try:
        out = MODEL.loglikes(params)
        c2 = -2.0 * float(np.sum(out[0]))
        if not np.isfinite(c2):
            return 1e9
        return c2
    except Exception:
        return 1e9


def main():
    global MODEL, N_EVAL
    print("Building model...", flush=True)
    MODEL = build_model()
    order = PARAM_ORDER
    x0 = np.array([START[n] * SCALE[n] for n in order])
    best_so_far = [1e18]
    t_start = time.time()

    def f(v):
        c2 = chi2_of(v)
        if c2 < best_so_far[0]:
            best_so_far[0] = c2
        if N_EVAL % 10 == 0:
            print(f"[free-A2] eval {N_EVAL}: chi2={c2:.3f} "
                  f"best={best_so_far[0]:.3f}", flush=True)
        return c2

    res = minimize(f, x0, method="Powell",
                   options={"maxiter": 40, "xtol": 1e-5, "ftol": 0.02,
                            "disp": False})
    dt = time.time() - t_start
    best = {n: float(res.x[order.index(n)]) / SCALE[n] for n in order}
    print(f"[free-A2] chi2 = {res.fun:.3f}  evals = {N_EVAL}  "
          f"time = {dt:.0f}s success={res.success}", flush=True)
    print("[free-A2] best-fit: " +
          " ".join(f"{k}={v:.6g}" for k, v in best.items()), flush=True)
    with open("/home/hatch/workspace/vsl-planck/act-dr6/results/free_A2.json", "w") as fo:
        json.dump({"chi2": float(res.fun), "best_fit": best, "evals": N_EVAL,
                   "seconds": dt, "success": bool(res.success)}, fo, indent=2)


if __name__ == "__main__":
    main()
