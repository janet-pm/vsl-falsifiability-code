"""Fits B and C: fixed-ns null tests. Standalone because the combined
script's process died silently after fit A (cause unknown; fit A results
were captured from the log). Starts from fit A's best fit."""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize
from scipy.stats import chi2 as chi2_dist

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model  # noqa: E402

NS_VSL = 0.96478
NS_VSL_THEORY_ERR = 0.00064
NS_VSL_REHEAT = 0.96838

# Fit A best fit, from fit_A_B_C.log (chi2 = 553.001, success=True)
A_BEST = {
    "ombh2": 0.0225922,
    "omch2": 0.119447,
    "cosmomc_theta": 0.0104074,
    "tau": 0.0565201,
    "As": 2.10008e-09,
    "ns": 0.973292,
    "P_act": 1.00128,
}
A_CHI2 = 553.001

PARAM_ORDER = ["ombh2", "omch2", "cosmomc_theta", "tau", "As", "ns", "P_act"]
SCALE = {"ombh2": 100.0, "omch2": 100.0, "cosmomc_theta": 1000.0,
         "tau": 100.0, "As": 1e9, "ns": 1.0, "P_act": 1.0}
CAMB_ARGS = {"lmax": 9000, "lens_potential_accuracy": 8,
             "min_l_logl_sampling": 6000}


def build_model():
    info = {
        "params": {
            "ombh2": {"prior": [0.018, 0.028]},
            "omch2": {"prior": [0.08, 0.16]},
            "cosmomc_theta": {"prior": [0.0103, 0.0105]},
            "tau": {"prior": [0.02, 0.12]},
            "As": {"prior": [1.5e-9, 2.8e-9]},
            "ns": {"prior": [0.90, 1.05]},
            "P_act": {"prior": [0.9, 1.1]},
            "r": 0,
        },
        "theory": {"camb": {"extra_args": CAMB_ARGS}},
        "likelihood": {
            "act_dr6_cmbonly": {
                "input_file": "dr6_data_cmbonly.fits",
                "params": {"A_act": 1.0},
            },
            "planck_2018_lowl.EE": None,
        },
    }
    return get_model(info)


MODEL = None
N_EVAL = 0


def chi2_of(scaled_vec, ns_fixed):
    global N_EVAL
    params = {n: float(s) / SCALE[n] for n, s in zip(PARAM_ORDER, scaled_vec)}
    params["ns"] = ns_fixed
    N_EVAL += 1
    try:
        out = MODEL.loglikes(params)
        c2 = -2.0 * float(np.sum(out[0]))  # true total chi2 (see note in main script)
        if not np.isfinite(c2):
            return 1e9
        return c2
    except Exception:
        return 1e9


def run_fit(label, ns_fixed, x0_dict, maxiter):
    global N_EVAL
    N_EVAL = 0
    t_start = time.time()
    order = [n for n in PARAM_ORDER if n != "ns"]
    x0 = np.array([x0_dict[n] * SCALE[n] for n in order])
    best_so_far = [1e18]

    def f(v):
        full = np.array([
            (v[order.index(n)] if n in order else ns_fixed * SCALE["ns"])
            for n in PARAM_ORDER])
        c2 = chi2_of(full, ns_fixed)
        if c2 < best_so_far[0]:
            best_so_far[0] = c2
        if N_EVAL % 10 == 0:
            print(f"[{label}] eval {N_EVAL}: chi2={c2:.3f} "
                  f"best={best_so_far[0]:.3f}", flush=True)
        return c2

    res = minimize(f, x0, method="Powell",
                   options={"maxiter": maxiter, "xtol": 1e-4, "ftol": 0.1,
                            "disp": False})
    dt = time.time() - t_start
    best = {n: (float(res.x[order.index(n)]) / SCALE[n] if n in order
                else ns_fixed)
            for n in PARAM_ORDER}
    print(f"[{label}] chi2 = {res.fun:.3f}  evals = {N_EVAL}  "
          f"time = {dt:.0f}s success={res.success}", flush=True)
    print(f"[{label}] best-fit: " +
          " ".join(f"{k}={v:.6g}" for k, v in best.items()), flush=True)
    return {"label": label, "chi2": float(res.fun), "best_fit": best,
            "evals": N_EVAL, "seconds": dt, "success": bool(res.success)}


def main():
    global MODEL
    print("Building model...", flush=True)
    MODEL = build_model()
    free = {"label": "act-free-ns", "chi2": A_CHI2, "best_fit": dict(A_BEST),
            "evals": 93, "seconds": 993, "success": True}
    fixed = run_fit("act-vsl-ns", NS_VSL, A_BEST, maxiter=15)
    reheat = run_fit("act-vsl-reheat-ns", NS_VSL_REHEAT, A_BEST, maxiter=15)

    def stats(fx):
        d = fx["chi2"] - A_CHI2
        p = float(chi2_dist.sf(d, 1)) if d >= 0 else 1.0
        return d, p

    d_vsl, p_vsl = stats(fixed)
    d_rh, p_rh = stats(reheat)
    sig = lambda d: float(np.sqrt(max(d, 0.0)))
    out = {
        "ns_vsl": NS_VSL,
        "ns_vsl_theory_err": NS_VSL_THEORY_ERR,
        "ns_vsl_reheat": NS_VSL_REHEAT,
        "free_fit": free,
        "vsl_fixed_fit": fixed,
        "vsl_reheat_fixed_fit": reheat,
        "delta_chi2_vsl": float(d_vsl),
        "p_value_vsl_1dof": p_vsl,
        "sigma_vsl_from_dchi2": sig(d_vsl),
        "delta_chi2_reheat": float(d_rh),
        "p_value_reheat_1dof": p_rh,
        "sigma_reheat_from_dchi2": sig(d_rh),
        "notes": ("ACT DR6 CMB-only lite + Planck lowl EE, r=0, A_act=1 fixed, "
                  "P_act varied. Powell minimization. chi2 = -2*sum(loglikes)."),
    }
    with open("/home/hatch/workspace/vsl-planck/act-dr6/results/null_test_act.json", "w") as f:
        json.dump(out, f, indent=2)
    print("\n==== RESULT ====", flush=True)
    print(f"free-fit n_s          : {A_BEST['ns']:.6f}  chi2={A_CHI2:.3f}", flush=True)
    print(f"chi2 VSL (0.96478)    : {fixed['chi2']:.3f}  dchi2={d_vsl:.3f} (~{sig(d_vsl):.2f} sigma)", flush=True)
    print(f"chi2 reheat (0.96838) : {reheat['chi2']:.3f}  dchi2={d_rh:.3f} (~{sig(d_rh):.2f} sigma)", flush=True)


if __name__ == "__main__":
    main()
