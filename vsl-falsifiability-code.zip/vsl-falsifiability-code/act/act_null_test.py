"""
ACT DR6 null test of the Afshordi-Magueijo (2016) VSL prediction.

VERIFIED + RUNNING. Likelihood: official ACT collaboration repo
(ACTCollaboration/dr6-cmbonly), cloned 2026-09-26 with James's explicit
authorization ("trust but verify"). Phase-1 verification: genuine org repo,
72 commits by Hidde T. Jense (Cardiff/ACT), tags v0.1.2..v1.0.1, code skim
clean (pure numpy/cobaya/sacc numerics; data download via cobaya-install
from NASA LAMBDA only). Installed with venv pip; sacc-2.4 pulled in.

CAVEAT (documented, not hidden): the repo's shipped self-test
(test_TTTEEE) expects loglike = -395.48 at its reference point; with our
stack (CAMB 2.0.4, sacc 2.4) we compute -392.90 (diff +2.58, i.e. 5.2 in
chi2). Almost certainly a dependency-version effect (repo CI uses unpinned
requirements; reference value dates to early 2025). Mitigation: our science
result is the *relative* chi2 between free and fixed-ns fits with identical
code, and we validate the ns direction against the published ACT-alone
result (n_s = 0.973 +/- 0.006, Louis et al. arXiv:2503.14452, independently
confirmed via blind ChatGPT literature check). If our free fit reproduces
~0.973, the likelihood is sound in the direction that matters.

BUG FOUND AND FIXED 2026-09-26: the first run of this script minimized
MODEL.loglikes(params)[1][0], copying the morning script's pattern. But
cobaya builds out[1] as *derived parameters*, and auto-generates a derived
"chi2__CMB" aggregating only likelihoods that declare CMB type. The custom
ACT likelihood declares no type, so out[1][0] was the *lowl-EE-only* chi2;
the first fit "converged" to crazy values (ombh2=0.0345, theta=0.01006) by
minimizing lowl alone. Fixed by using -2*sum(out[0]) = true total chi2.
The morning Planck test was NOT affected: all its likelihoods are built-in
CMB type, so its chi2__CMB was the genuine total (and its ns=0.964777
matches the published value, confirming correctness).

Pattern mirrors ~/workspace/vsl-planck/code/null_test.py (Powell, scaled
params, r=0 fixed).
  Fit A: ACT DR6 + lowl EE, free LCDM (6 cosmo + P_act) -> best-fit n_s, chi2
  Fit B: n_s fixed = 0.96478 (VSL minimal) -> chi2, delta_chi2, sigma
  Fit C: n_s fixed = 0.96838 (VSL reheating escape hatch) -> chi2, ...
  Fit D (stretch): ACT DR6 + Planck via PlanckActCut variant
"""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize
from scipy.stats import chi2 as chi2_dist

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model  # noqa: E402

NS_VSL = 0.96478            # Afshordi & Magueijo 2016, minimal critical model
NS_VSL_THEORY_ERR = 0.00064
NS_VSL_REHEAT = 0.96838    # reheating escape hatch (reheat by 1e10)

START = {
    "ombh2": 0.0224,
    "omch2": 0.1200,
    "cosmomc_theta": 0.01041,
    "tau": 0.060,
    "As": 2.10e-9,
    "ns": 0.973,           # start near the ACT DR6 published value
    "P_act": 1.0,
}
PARAM_ORDER = ["ombh2", "omch2", "cosmomc_theta", "tau", "As", "ns", "P_act"]
SCALE = {"ombh2": 100.0, "omch2": 100.0, "cosmomc_theta": 1000.0,
         "tau": 100.0, "As": 1e9, "ns": 1.0, "P_act": 1.0}

CAMB_ARGS = {"lmax": 9000, "lens_potential_accuracy": 8,
             "min_l_logl_sampling": 6000}   # same as repo self-test


def build_model():
    info = {
        "params": {
            "ombh2": {"prior": [0.018, 0.028]},
            "omch2": {"prior": [0.08, 0.16]},
            "cosmomc_theta": {"prior": [0.0103, 0.0105]},
            "tau": {"prior": [0.02, 0.12]},
            "As": {"prior": [1.5e-9, 2.8e-9]},
            "ns": {"prior": [0.90, 1.05]},
            "P_act": {"prior": [0.9, 1.1]},
            "r": 0,
        },
        "theory": {"camb": {"extra_args": CAMB_ARGS}},
        "likelihood": {
            "act_dr6_cmbonly": {
                "input_file": "dr6_data_cmbonly.fits",
                "params": {"A_act": 1.0},   # dipole-calibrated, ~fixed
            },
            "planck_2018_lowl.EE": None,    # pins tau (collab. uses sroll2;
                                           # unavailable; this is equivalent)
        },
    }
    return get_model(info)


MODEL = None
N_EVAL = 0


def chi2_of(scaled_vec, ns_fixed=None):
    global N_EVAL
    params = {n: float(s) / SCALE[n] for n, s in zip(PARAM_ORDER, scaled_vec)}
    if ns_fixed is not None:
        params["ns"] = ns_fixed
    N_EVAL += 1
    try:
        out = MODEL.loglikes(params)
        # TOTAL chi2 = -2 * sum of per-likelihood loglikes. Do NOT use
        # out[1][0]: cobaya auto-generates a derived "chi2__CMB" that only
        # aggregates likelihoods declaring CMB type, and the custom ACT
        # likelihood does not declare it, so out[1][0] would be lowl-only.
        # (The morning Planck test was unaffected: all its likelihoods are
        # built-in CMB type, so chi2__CMB was the total there.)
        c2 = -2.0 * float(np.sum(out[0]))
        if not np.isfinite(c2):
            return 1e9
        return c2
    except Exception:
        return 1e9


def run_fit(label, ns_fixed, x0_dict, maxiter):
    global N_EVAL
    N_EVAL = 0
    t_start = time.time()
    if ns_fixed is None:
        order = PARAM_ORDER
    else:
        order = [n for n in PARAM_ORDER if n != "ns"]
    x0 = np.array([x0_dict[n] * SCALE[n] for n in order])
    best_so_far = [1e18]

    def f(v):
        full = np.array([
            (v[order.index(n)] if n in order else ns_fixed * SCALE["ns"])
            for n in PARAM_ORDER])
        c2 = chi2_of(full, ns_fixed=ns_fixed)
        if c2 < best_so_far[0]:
            best_so_far[0] = c2
        if N_EVAL % 10 == 0:
            print(f"[{label}] eval {N_EVAL}: chi2={c2:.3f} "
                  f"best={best_so_far[0]:.3f}", flush=True)
        return c2

    res = minimize(f, x0, method="Powell",
                   options={"maxiter": maxiter, "xtol": 1e-4, "ftol": 0.1,
                            "disp": False})
    dt = time.time() - t_start
    best = {n: (float(res.x[order.index(n)]) / SCALE[n] if n in order
                else ns_fixed)
            for n in PARAM_ORDER}
    print(f"[{label}] chi2 = {res.fun:.3f}  evals = {N_EVAL}  "
          f"time = {dt:.0f}s success={res.success}", flush=True)
    print(f"[{label}] best-fit: " +
          " ".join(f"{k}={v:.6g}" for k, v in best.items()), flush=True)
    return {"label": label, "chi2": float(res.fun), "best_fit": best,
            "evals": N_EVAL, "seconds": dt, "success": bool(res.success)}


def main():
    global MODEL
    print("Building Cobaya model (CAMB + ACT DR6 + lowl EE)...", flush=True)
    MODEL = build_model()

    free = run_fit("act-free-ns", ns_fixed=None, x0_dict=START, maxiter=25)
    fixed = run_fit("act-vsl-ns", ns_fixed=NS_VSL,
                    x0_dict=free["best_fit"], maxiter=15)
    reheat = run_fit("act-vsl-reheat-ns", ns_fixed=NS_VSL_REHEAT,
                     x0_dict=free["best_fit"], maxiter=15)

    def stats(fx):
        d = fx["chi2"] - free["chi2"]
        p = float(chi2_dist.sf(d, 1)) if d >= 0 else 1.0
        return d, p

    d_vsl, p_vsl = stats(fixed)
    d_rh, p_rh = stats(reheat)
    sig = lambda d: float(np.sqrt(max(d, 0.0)))  # 1-dof chi2 -> ~sigma

    # sigma including theory error on the prediction, using published-style
    # error propagation is not available from a minimizer; report the
    # chi2-based sigma and note the theory error separately.
    out = {
        "ns_vsl": NS_VSL,
        "ns_vsl_theory_err": NS_VSL_THEORY_ERR,
        "ns_vsl_reheat": NS_VSL_REHEAT,
        "free_fit": free,
        "vsl_fixed_fit": fixed,
        "vsl_reheat_fixed_fit": reheat,
        "delta_chi2_vsl": float(d_vsl),
        "p_value_vsl_1dof": p_vsl,
        "sigma_vsl_from_dchi2": sig(d_vsl),
        "delta_chi2_reheat": float(d_rh),
        "p_value_reheat_1dof": p_rh,
        "sigma_reheat_from_dchi2": sig(d_rh),
        "self_test_caveat": (
            "Repo self-test expects loglike=-395.48 at reference point; "
            "this stack gives -392.90 (CAMB 2.0.4 / sacc 2.4 version effect). "
            "Science result uses relative chi2 only; ns direction validated "
            "against published ACT-alone ns=0.973+-0.006."
        ),
        "notes": (
            "r=0 fixed in all fits. A_act=1.0 fixed (dipole prior ~delta). "
            "P_act varied. Likelihood: ACT DR6 CMB-only lite + Planck lowl EE "
            "for tau. Theory: CAMB lmax=9000. Minimizer: Powell."
        ),
    }
    with open("/home/hatch/workspace/vsl-planck/act-dr6/results/"
              "null_test_act.json", "w") as f:
        json.dump(out, f, indent=2)
    print("\n==== RESULT ====", flush=True)
    print(f"free-fit n_s         : {free['best_fit']['ns']:.6f}", flush=True)
    print(f"chi2 free            : {free['chi2']:.3f}", flush=True)
    print(f"chi2 VSL (0.96478)   : {fixed['chi2']:.3f}  "
          f"dchi2={d_vsl:.3f} (~{sig(d_vsl):.2f} sigma)", flush=True)
    print(f"chi2 reheat (0.96838) : {reheat['chi2']:.3f}  "
          f"dchi2={d_rh:.3f} (~{sig(d_rh):.2f} sigma)", flush=True)


if __name__ == "__main__":
    main()
