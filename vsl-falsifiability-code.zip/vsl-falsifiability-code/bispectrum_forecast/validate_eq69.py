"""Validate Eq. 6.9 (Mylova et al. 2112.08179) folded coefficient.

The paper predicts that in the flattened limit (k3 -> k1+k2),
  S^bithermal -> C_fold * (1+x2-x3)^(-3/2),  C_fold = -3*pi/4.
We verify that our B_zeta_flat template reproduces this coefficient
by fitting the (k1+k2-k3) dependence near the folded limit.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import B_zeta_flat, As

C_EXPECT = -3*np.pi/4

def infer_cfold(k=0.1, deltas=(0.02, 0.01, 0.005)):
    """Fit B_flat(k,k,k3) ~ const * ((2k-k3)/k3)^(-3/2) as k3->2k,
    return inferred C_fold via the paper's S definition."""
    from common import h
    # Use S = (k1k2k3)^2 B_Phi / A^2, B_Phi = (3/5)^3 B_zeta,
    # A = (9/25)(2pi^2 As).  In folded limit S -> C_fold*(1+x2-x3)^(-3/2).
    A = (9/25)*(2*np.pi**2*As)
    out = []
    for d in deltas:
        k1 = k; k2 = k
        # sample k3 approaching 2k from below, well above regulator scale
        eps = np.array([0.05, 0.08, 0.12, 0.18])*k
        k3 = 2*k - eps
        Bz = np.array([B_zeta_flat(k1, k2, kk, fNL=1.0, delta=d) for kk in k3])
        Bp = (3/5)**3 * Bz
        S = (k1*k2*k3)**2 * Bp / A**2
        x = (1 + k2/k1 - k3/k1)   # = (k1+k2-k3)/k1
        # S / x^(-3/2) should -> C_fold
        ratio = S / x**(-1.5)
        out.append((d, ratio))
    return out

if __name__ == "__main__":
    print(f"Expected C_fold = -3*pi/4 = {C_EXPECT:.4f}")
    for d, ratio in infer_cfold():
        print(f"delta={d}: inferred C_fold -> {ratio[-1]:.4f} "
              f"(samples: {np.round(ratio,4)})")
