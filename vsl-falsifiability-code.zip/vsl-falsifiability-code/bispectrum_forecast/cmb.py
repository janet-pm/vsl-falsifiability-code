"""CMB bispectrum Fisher forecast (temperature only).

Local shape via exact separable line-of-sight integrals (validates the
weights/noise/triangle counting against Planck sigma(fNL^local)~5).
Flattened shape via Fourier (omega) decomposition of the folded kernel,
using the SAME grids/weights/noise; the ratio F_flat/F_local is the
robust quantity.

Conventions:
  b_{l1l2l3} = (2/pi)^3 int dk1dk2dk3 (k1k2k3)^2 B_zeta T1T2T3
                x int dx x^2 j_{l1}(k1x)j_{l2}(k2x)j_{l3}(k3x)
  B_{l1l2l3} = sqrt((2l1+1)(2l2+1)(2l3+1)/4pi) (l1 l2 l3; 0 0 0) b_{l1l2l3}
  F = f_sky sum_{l1<=l2<=l3} W * B^2 / (Delta*Ctot1*Ctot2*Ctot3)
with Delta = 6/2/1 and W the binned-triangle weight.
"""
import numpy as np
from scipy.special import spherical_jn
try:
    from .common import (P_zeta, B_zeta_local, B_zeta_flat, get_camb_results,
                         wigner3j_000, h, As)
except ImportError:
    from common import (P_zeta, B_zeta_local, B_zeta_flat, get_camb_results,
                        wigner3j_000, h, As)

C_LIGHT = 299792.458
TCMB_UK = 2.7255e6  # uK; CAMB transfer functions are in dT/T_CMB units


class CMBExperiment:
    def __init__(self, name, f_sky, lmin, lmax, beam_arcmin, dT_uKarcmin,
                 lmax_camb=3000, kmax=0.6):
        self.name = name
        self.f_sky = f_sky
        self.lmin = lmin
        self.lmax = lmax
        self.beam = beam_arcmin
        self.dT = dT_uKarcmin
        self._camb = None
        self._Tl = {}
        self._kmax = kmax
        self._lmax_camb = lmax_camb

    # ---------- CAMB ----------
    def _setup(self):
        if self._camb is not None:
            return
        import camb
        res = get_camb_results(lmax=self._lmax_camb, kmax=self._kmax)
        self._camb = res
        td = res.get_cmb_transfer_data()
        self._td = td
        L, q, T = (np.asarray(a) for a in td.get_transfer(source=0))
        from scipy.interpolate import RegularGridInterpolator
        # T is in dT/T_CMB; convert to uK. L-grid is sparse -> 2D interp.
        self._Tinterp = RegularGridInterpolator(
            (L, q), T * TCMB_UK, bounds_error=False, fill_value=0.0)
        self._Tq = q
        # lensed scalar TT for variance (raw C_l in uK^2)
        cl = res.get_cmb_power_spectra(CMB_unit='muK', raw_cl=True)
        self._clTT = cl['lensed_scalar'][:, 0]  # muK^2
        self._lcl = np.arange(len(self._clTT))

    def transfer_T(self, l, k):
        """Temperature transfer T_l(k) in uK, k in Mpc^-1 (l-interpolated)."""
        self._setup()
        k = np.asarray(k, dtype=float)
        pts = np.column_stack([np.full_like(k, float(l)), k])
        return self._Tinterp(pts)

    def cl_tot(self, l):
        """Lensed C_l + noise in muK^2."""
        self._setup()
        li = int(np.clip(round(l), 0, len(self._clTT) - 1))
        cl = self._clTT[li]
        sig_b = np.radians(self.beam / 60.0) / np.sqrt(8 * np.log(2))
        nl = (self.dT * np.pi / 10800.0) ** 2 * np.exp(
            l * (l + 1) * sig_b**2)
        return cl + nl

    # ---------- l grid & triangle weights ----------
    def lgrid(self, nlog=30, llin=60):
        """Partition [lmin,lmax] into bins with width>=1.
        Linear 2..llin, then log-spaced. Returns centers and widths."""
        l1 = np.arange(max(self.lmin, 2), llin + 1)
        l2 = np.unique(np.round(np.exp(
            np.linspace(np.log(llin + 1), np.log(self.lmax), nlog)))).astype(int)
        l2 = l2[(l2 > llin) & (l2 <= self.lmax)]
        ls = np.concatenate([l1, l2])
        # bin edges at midpoints; first/last extended by half width
        edges = np.concatenate(
            [[ls[0] - 0.5], (ls[:-1] + ls[1:]) / 2.0, [ls[-1] + (ls[-1] - ls[-2]) / 2.0]])
        edges[0] = max(edges[0], self.lmin - 0.5)
        dl = np.diff(edges)
        assert (dl >= 1.0 - 1e-9).all(), f"bin width <1: {dl.min()}"
        self._ledges = edges
        return ls, dl

    def _tri_frac_edges(self, i, j, k, nsamp=40000):
        """Fraction of integer triplets in bins (i,j,k) satisfying triangle
        AND even parity (3j selection rule)."""
        e = self._ledges
        rng = np.random.default_rng(123)
        ai = np.arange(int(np.ceil(e[i])), int(np.floor(e[i+1])) + 1)
        aj = np.arange(int(np.ceil(e[j])), int(np.floor(e[j+1])) + 1)
        ak = np.arange(int(np.ceil(e[k])), int(np.floor(e[k+1])) + 1)
        if len(ai) == 0 or len(aj) == 0 or len(ak) == 0:
            return 0.0
        a = rng.choice(ai, nsamp)
        b = rng.choice(aj, nsamp)
        c = rng.choice(ak, nsamp)
        ok = ((a + b > c) & (b + c > a) & (c + a > b)
              & ((a + b + c) % 2 == 0))
        return ok.mean()

    def _tri_frac(self, l1, l2, l3, d1, d2, d3, nsamp=20000):
        rng = np.random.default_rng(0)
        a = l1 + (rng.random(nsamp) - 0.5) * d1
        b = l2 + (rng.random(nsamp) - 0.5) * d2
        c = l3 + (rng.random(nsamp) - 0.5) * d3
        ok = (a + b > c) & (b + c > a) & (c + a > b) & (a > 0) & (b > 0) & (c > 0)
        return ok.mean()

    # ---------- separable local ----------
    def _line_of_sight_AB(self, ls, xk, kk):
        """alpha_l(x), beta_l(x) on grids. xk: x in Mpc, kk: k in Mpc^-1."""
        nl, nx, nk = len(ls), len(xk), len(kk)
        alpha = np.zeros((nl, nx))
        beta = np.zeros((nl, nx))
        Pk = P_zeta(kk)
        for i, l in enumerate(ls):
            Tl = self.transfer_T(l, kk)
            # j_l(kx): (nx, nk)
            jl = spherical_jn(l, np.outer(xk, kk))
            alpha[i] = (2 / np.pi) * np.trapezoid(
                (kk**2)[None, :] * Tl[None, :] * jl, kk, axis=1)
            beta[i] = (2 / np.pi) * np.trapezoid(
                (kk**2 * Pk)[None, :] * Tl[None, :] * jl, kk, axis=1)
        return alpha, beta

    def _xgrid(self):
        """x-grid dense at recombination (alpha,beta peak ~20 Mpc wide)."""
        xf = np.linspace(13600, 14400, 400)
        xc = np.linspace(0, 13600, 80, endpoint=False)
        return np.concatenate([xc, xf])

    def b_local_grid(self, ls, dl, xk=None, kk=None):
        """Reduced bispectrum b_{l1l2l3} for fNL=1 local on grid triangles."""
        if xk is None:
            xk = self._xgrid()
        if kk is None:
            kk = np.linspace(5e-5, 0.4, 4000)
        alpha, beta = self._line_of_sight_AB(ls, xk, kk)
        x2 = xk**2
        tris = []
        nl = len(ls)
        for i in range(nl):
            for j in range(i, nl):
                for k in range(j, nl):
                    # bin can straddle the triangle boundary; MC fraction
                    # (includes triangle + even-parity selection)
                    e = self._ledges
                    if e[i+1] + e[j+1] <= e[k]:
                        continue  # no part of bin satisfies triangle
                    ftri = self._tri_frac_edges(i, j, k)
                    if ftri <= 0:
                        continue
                    integ = (alpha[i] * beta[j] * beta[k]
                             + alpha[j] * beta[k] * beta[i]
                             + alpha[k] * beta[i] * beta[j])
                    b = (6.0 / 5.0) * np.trapezoid(x2 * integ, xk)
                    tris.append((i, j, k, b, ftri))
        return tris

    # ---------- Fisher ----------
    def fisher(self, tris, ls, dl):
        F = 0.0
        for (i, j, k, b, ftri) in tris:
            l1, l2, l3 = ls[i], ls[j], ls[k]
            # 3j needs even parity; shift l1 by 1 if odd (b is smooth)
            q1, q2, q3 = l1, l2, l3
            if (q1 + q2 + q3) % 2 == 1:
                q1 += 1
            w3j = wigner3j_000(q1, q2, q3)
            if w3j == 0.0:
                continue
            B = np.sqrt((2 * q1 + 1) * (2 * q2 + 1) * (2 * q3 + 1)
                        / (4 * np.pi)) * w3j * b
            if i == j == k:
                delta = 6.0
            elif i == j or j == k:
                delta = 2.0
            else:
                delta = 1.0
            W = dl[i] * dl[j] * dl[k] * ftri
            var = delta * self.cl_tot(l1) * self.cl_tot(l2) * self.cl_tot(l3)
            F += W * B**2 / var
        return self.f_sky * F

    def sigma_local(self, nlog=30):
        ls, dl = self.lgrid(nlog=nlog)
        tris = self.b_local_grid(ls, dl)
        F = self.fisher(tris, ls, dl)
        return 1.0 / np.sqrt(F), len(tris)
