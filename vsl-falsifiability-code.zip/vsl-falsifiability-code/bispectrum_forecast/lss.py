"""Galaxy-bispectrum Fisher forecast for primordial non-Gaussianity.

Single effective tracer per redshift bin, tree-level real-space model:
  B_g = b1^3 M1 M2 M3 B_zeta + b1^2 b2 [P_L(k1) P_L(k2) + cyc]
  Var(B_g) = s_123 P_tot(k1) P_tot(k2) P_tot(k3) / N_tri
  N_tri    = V k1 k2 k3 (dk)^3 / pi        (Sefusatti & Komatsu 2007)
with P_tot = b1^2 P_L + 1/n, M(k,z) = sqrt(P_lin(k,z)/P_zeta(k)) from CAMB.

Only dB/d(fNL) enters (gravity bispectrum does not depend on fNL).
Gaussian variance only; no RSD (real space); no scale-dependent-bias
power-spectrum info (bispectrum only -> conservative for squeezed).
"""
import numpy as np
try:
    from .common import P_zeta, B_zeta_local, B_zeta_flat, get_camb_results, h
except ImportError:
    from common import P_zeta, B_zeta_local, B_zeta_flat, get_camb_results, h


class Survey:
    def __init__(self, name, zbins, f_sky, kmax_hmpc=0.2):
        """
        zbins: list of (zmin, zmax, n_hmpc3, b1) with n in (Mpc/h)^-3.
        """
        self.name = name
        self.zbins = zbins
        self.f_sky = f_sky
        self.kmax = kmax_hmpc * h          # -> Mpc^-1
        self._camb = None
        self._Mk = {}

    def _setup(self):
        if self._camb is not None:
            return
        zs = sorted(set([round(0.5 * (a + b), 3) for (a, b, n, b1) in self.zbins]))
        res = get_camb_results(lmax=2000, kmax=1.0, redshifts=zs)
        self._camb = res
        # comoving distances for volumes
        self._chi = {}   # z -> chi in Mpc (flat)
        zs = np.linspace(0.01, 3.0, 300)
        chis = np.array([res.comoving_radial_distance(z) for z in zs])
        self._zgrid, self._chigrid = zs, chis

    def chi(self, z):
        self._setup()
        return np.interp(z, self._zgrid, self._chigrid)

    def volume(self, zmin, zmax):
        c1, c2 = self.chi(zmin), self.chi(zmax)
        return self.f_sky * 4 * np.pi / 3 * (c2**3 - c1**3)   # Mpc^3

    def matter_power(self, k_mpc, z):
        """Linear P(k,z) in Mpc^3 from CAMB (interpolated)."""
        self._setup()
        key = round(float(z), 3)
        if key not in self._Mk:
            pki = self._camb.get_matter_power_interpolator(
                nonlinear=False, var1='delta_tot', var2='delta_tot')
            k = np.logspace(-4, np.log10(2.0), 400)   # h/Mpc
            pk = pki.P(z, k) * h**3                   # -> Mpc^3
            self._Mk[key] = (k * h, pk)               # k in Mpc^-1
        k, pk = self._Mk[key]
        return np.interp(k_mpc, k, pk, left=0.0, right=0.0)

    def M_of_k(self, k_mpc, z):
        Pl = self.matter_power(k_mpc, z)
        Pz = P_zeta(k_mpc)
        return np.sqrt(np.where(Pz > 0, Pl / Pz, 0.0))

    def fisher_fnl(self, shape="local", delta=0.05, verbose=False):
        """Return sigma(fNL) for shape in {'local','flat'}."""
        F = 0.0
        for (zmin, zmax, n_h, b1) in self.zbins:
            z = 0.5 * (zmin + zmax)
            V = self.volume(zmin, zmax)
            n = n_h * h**3                  # -> Mpc^-3
            kf = 2 * np.pi / V**(1.0 / 3.0)
            ks = np.arange(kf, self.kmax, kf)
            if len(ks) < 3:
                continue
            M = self._M_of_k_vec(ks, z)
            PL = M**2 * P_zeta(ks)
            Ptot = b1**2 * PL + 1.0 / n
            F += self._bin_fisher(ks, kf, V, M, PL, Ptot, b1, shape, delta)
            if verbose:
                print(f"  z=[{zmin},{zmax}] V={V/1e9:.1f} Gpc^3 "
                      f"kf={kf:.4f} Nk={len(ks)} F={F:.3f}")
        return 1.0 / np.sqrt(F)

    def _M_of_k_vec(self, ks, z):
        return np.array([self.M_of_k(k, z) for k in ks])

    def _bin_fisher(self, ks, kf, V, M, PL, Ptot, b1, shape, delta):
        F = 0.0
        nk = len(ks)
        # ordered triangles k1<=k2<=k3, triangle condition k1+k2>k3
        for i in range(nk):
            k1 = ks[i]
            for j in range(i, nk):
                k2 = ks[j]
                k3max = k1 + k2
                for k in range(j, nk):
                    k3 = ks[k]
                    if k3 > k3max:
                        break
                    # symmetry factor
                    if i == j == k:
                        s123 = 6.0
                    elif i == j or j == k:
                        s123 = 2.0
                    else:
                        s123 = 1.0
                    if shape == "local":
                        dB = (b1**3 * M[i] * M[j] * M[k]
                              * B_zeta_local(k1, k2, k3, fNL=1.0))
                    else:
                        dB = (b1**3 * M[i] * M[j] * M[k]
                              * B_zeta_flat(k1, k2, k3, fNL=1.0, delta=delta))
                    Ntri = V * k1 * k2 * k3 * kf**3 / np.pi
                    var = s123 * Ptot[i] * Ptot[j] * Ptot[k] / Ntri
                    F += dB**2 / var
        return F
