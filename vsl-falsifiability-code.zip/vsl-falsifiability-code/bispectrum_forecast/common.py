"""Shared cosmology, primordial templates, and CAMB interface for the
flattened-VSL non-Gaussianity detectability forecast.

Conventions (verified against Mylova et al. 2022, JCAP 07 (2022) 005):
- Curvature perturbation zeta; P_zeta(k) = 2 pi^2 A_s k^-3 (k/kp)^(ns-1).
- Local: B_zeta = (6/5) fNL [P(k1)P(k2) + cyc]      (Planck convention)
- Paper's shape S: S = (k1 k2 k3)^2 B_Phi / (6 A^2), P_Phi = A k^-3,
  B_Phi^local = 2 fNL [P_Phi(k1) P_Phi(k2) + cyc]    (WMAP convention)
  => B_zeta = 3.6 (2 pi^2 A_s)^2 S / (k1 k2 k3)^2.
- Flattened template (this work), matched to the paper's Eq. 6.9 folded
  asymptotics S -> C_fold (1+x2-x3)^(-3/2) with C_fold = -3*pi/4:
      B_zeta^flat = 3.6 (2 pi^2 A_s)^2 C_fold
                    * sum_a [ ((kb+kc-ka)/ka)^2 + delta^2 ]^(-3/4)
                            / (ka^2 kb^2 kc^2)
  fNL^flat = 1 is DEFINED as the 2022 paper's predicted amplitude.
  delta = fractional folded regulator (their unknown UV cutoff).
"""
import numpy as np

# ---- fiducial cosmology: Planck 2018 TTTEEE+lowE+lensing ----
H0 = 67.4            # km/s/Mpc
h = H0 / 100.0
ombh2 = 0.02237
omch2 = 0.1200
tau = 0.054
As = 2.1e-9
ns = 0.965
kp = 0.05            # Mpc^-1 pivot
Om = (ombh2 + omch2) / h**2

C_FOLD = -3.0 * np.pi / 4.0   # -2.35619, from Eq. 6.9 folded expansion


def P_zeta(k):
    k = np.asarray(k, dtype=float)
    return 2 * np.pi**2 * As * k**-3 * (k / kp) ** (ns - 1.0)


def B_zeta_local(k1, k2, k3, fNL=1.0):
    P1, P2, P3 = P_zeta(k1), P_zeta(k2), P_zeta(k3)
    return (6.0 / 5.0) * fNL * (P1 * P2 + P2 * P3 + P3 * P1)


def B_zeta_flat(k1, k2, k3, fNL=1.0, delta=0.05):
    """Flattened template matched to Mylova et al. 2022 Eq. 6.9.

    Near the folded limit (k3 -> k1+k2) the paper's shape is
        S -> C_fold * (1+x2-x3)^(-3/2),  C_fold = -3*pi/4,
    with x2=k2/k1, x3=k3/k1, i.e. folded variable (k1+k2-k3)/k1.
    B_zeta = 0.6 (2 pi^2 A_s)^2 S / (k1 k2 k3)^2
    (from S=(k1k2k3)^2 B_Phi/A^2, Phi=(3/5)zeta, P_Phi=A/k^3).

    This template reproduces that folded asymptotic exactly (up to the
    regulator delta, which stands in for their unknown UV cutoff).
    The three folded permutations use cyclic reference scales so each
    matches the paper's (k_b+k_c-k_a)/k_ref form.

    fNL=1 is DEFINED as the 2022 paper's predicted folded amplitude.
    delta : fractional regulator of the folded divergence.
    k's in Mpc^-1; returns Mpc^6.
    """
    k1 = np.asarray(k1, dtype=float); k2 = np.asarray(k2, dtype=float)
    k3 = np.asarray(k3, dtype=float)
    # Prefactor derivation: S=(k1k2k3)^2 B_Phi/A^2 (Eq. 6.2), Phi=(3/5)zeta,
    # P_Phi(k)=A/k^3 with A=(9/25)(2pi^2 As). Thus
    # B_zeta=(5/3)^3 B_Phi = (125/27)A^2 S/(k1k2k3)^2
    #       = 0.6*(2pi^2 As)^2 * S/(k1k2k3)^2.
    amp = 0.6 * (2 * np.pi**2 * As) ** 2 * C_FOLD * fNL
    # Cyclic reference scales: t1 (k1 folded) ref k2; t2 (k2 folded) ref k3;
    # t3 (k3 folded) ref k1 -- matches paper's (1+x2-x3) variable.
    t1 = (((k2 + k3 - k1) / k2) ** 2 + delta**2) ** (-0.75) / (k1**2 * k2**2 * k3**2)
    t2 = (((k1 + k3 - k2) / k3) ** 2 + delta**2) ** (-0.75) / (k1**2 * k2**2 * k3**2)
    t3 = (((k1 + k2 - k3) / k1) ** 2 + delta**2) ** (-0.75) / (k1**2 * k2**2 * k3**2)
    return amp * (t1 + t2 + t3)


def get_camb_results(lmax=3000, kmax=1.0, redshifts=None):
    import camb
    pars = camb.CAMBparams()
    pars.set_cosmology(H0=H0, ombh2=ombh2, omch2=omch2, tau=tau)
    pars.InitPower.set_params(As=As, ns=ns, pivot_scalar=kp)
    pars.set_for_lmax(lmax, lens_potential_accuracy=1)
    pars.WantTransfer = True
    pars.Transfer.kmax = kmax
    if redshifts is not None:
        pars.set_matter_power(redshifts=redshifts, kmax=kmax)
    return camb.get_results(pars)


def wigner3j_000(l1, l2, l3):
    """Wigner 3j symbol (l1 l2 l3; 0 0 0) via sympy-free Racah formula."""
    # Use scipy? Not available -> implement via factorials (l up to ~3000 fine
    # in log space).
    if (l1 + l2 + l3) % 2 == 1:
        return 0.0
    if not (abs(l1 - l2) <= l3 <= l1 + l2):
        return 0.0
    from math import lgamma, exp
    # (l1 l2 l3; 0 0 0) = (-1)^((l1+l2+l3)/2) * sqrt(prod) * ...
    # closed form:
    s = (l1 + l2 + l3) // 2
    # = (-1)^s * [ (2s-2l1)! (2s-2l2)! (2s-2l3)! / (2s+1)! ]^{1/2}
    #             * s! / ((s-l1)! (s-l2)! (s-l3)!)
    def lf(n):
        return lgamma(n + 1)
    logv = 0.5 * (lf(2 * s - 2 * l1) + lf(2 * s - 2 * l2) + lf(2 * s - 2 * l3)
                  - lf(2 * s + 1))
    logv += lf(s) - lf(s - l1) - lf(s - l2) - lf(s - l3)
    return ((-1) ** s) * exp(logv)
