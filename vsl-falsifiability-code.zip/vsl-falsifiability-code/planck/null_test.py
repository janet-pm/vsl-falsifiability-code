"""
Null test: Afshordi & Magueijo (2016) VSL prediction vs Planck 2018 data.

VSL "critical geometry" model predicts n_s = 0.96478 (theory unc. 0.00064)
and r = 0 (no primordial tensors).

Test: fit base LCDM to Planck 2018 (high-l TTTEEE lite + low-l TT + low-l EE)
  (A) with n_s free  -> chi2_free
  (B) with n_s fixed = 0.96478, r = 0 -> chi2_fixed
Delta_chi2 (1 dof) measures consistency of the VSL prediction with the data.

r is fixed to 0 in BOTH runs (Planck only gives an upper bound r<0.10, and
VSL predicts exactly 0, so r carries no discriminating power here).
A_planck (overall calibration) fixed to 1, standard practice.
"""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize
from scipy.stats import chi2 as chi2_dist

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model

NS_VSL = 0.96478          # Afshordi & Magueijo 2016 prediction
NS_VSL_THEORY_ERR = 0.00064

# Planck 2018 TTTEEE+lowE+lensing best fits (arXiv:1807.06211, Table 2)
START = {
    "ombh2": 0.02237,
    "omch2": 0.1200,
    "cosmomc_theta": 0.0104092,          # theta_MC
    "tau": 0.0544,
    "As": float(np.exp(3.044) * 1e-10),  # from ln(1e10 As) = 3.044
    "ns": 0.9649,
}
PARAM_ORDER = ["ombh2", "omch2", "cosmomc_theta", "tau", "As", "ns"]
SCALE = {"ombh2": 100.0, "omch2": 100.0, "cosmomc_theta": 1000.0,
         "tau": 100.0, "As": 1e9, "ns": 1.0}


def build_model():
    info = {
        "params": {
            "ombh2": {"prior": [0.018, 0.028]},
            "omch2": {"prior": [0.08, 0.16]},
            "cosmomc_theta": {"prior": [0.0103, 0.0105]},
            "tau": {"prior": [0.02, 0.12]},
            "As": {"prior": [1.5e-9, 2.8e-9]},
            "ns": {"prior": [0.90, 1.05]},
            "r": 0,
            "A_planck": 1,
        },
        "theory": {"camb": {"extra_args": {"lmax": 2700}}},
        "likelihood": {
            "planck_2018_highl_plik.TTTEEE_lite": None,
            "planck_2018_lowl.TT": None,
            "planck_2018_lowl.EE": None,
        },
    }
    return get_model(info)


MODEL = None
N_EVAL = 0


def chi2_of(scaled_vec, free_ns=True):
    """chi2 = -2 ln L for scaled parameter vector."""
    global N_EVAL
    params = {n: float(s) / SCALE[n] for n, s in zip(PARAM_ORDER, scaled_vec)}
    if not free_ns:
        params["ns"] = NS_VSL
    N_EVAL += 1
    try:
        out = MODEL.loglikes(params)
        c2 = float(out[1][0])  # Cobaya returns (loglikes, [chi2])
        if not np.isfinite(c2):
            return 1e9
        return c2
    except Exception:
        return 1e9


def run_fit(label, free_ns, x0_dict):
    global N_EVAL
    N_EVAL = 0
    t_start = time.time()
    if free_ns:
        order = PARAM_ORDER
        x0 = np.array([x0_dict[n] * SCALE[n] for n in order])
    else:
        order = [n for n in PARAM_ORDER if n != "ns"]
        x0 = np.array([x0_dict[n] * SCALE[n] for n in order])
    best_so_far = [1e18]

    def f(v):
        full = np.array([
            (v[order.index(n)] if n in order else NS_VSL * SCALE["ns"])
            for n in PARAM_ORDER])
        c2 = chi2_of(full, free_ns=free_ns)
        if c2 < best_so_far[0]:
            best_so_far[0] = c2
        if N_EVAL % 25 == 0:
            print(f"[{label}] eval {N_EVAL}: chi2={c2:.3f} "
                  f"best={best_so_far[0]:.3f}", flush=True)
        return c2

    # Powell, few iterations: we start essentially at the minimum already.
    res = minimize(f, x0, method="Powell",
                   options={"maxiter": 30, "xtol": 1e-4, "ftol": 0.1,
                            "disp": False})
    dt = time.time() - t_start
    best = {n: (float(res.x[order.index(n)]) / SCALE[n] if n in order
                else NS_VSL)
            for n in PARAM_ORDER}
    print(f"[{label}] chi2 = {res.fun:.3f}  evals = {N_EVAL}  "
          f"time = {dt:.0f}s", flush=True)
    print(f"[{label}] best-fit: " +
          " ".join(f"{k}={v:.6g}" for k, v in best.items()), flush=True)
    return {"label": label, "chi2": float(res.fun), "best_fit": best,
            "evals": N_EVAL, "seconds": dt}


def main():
    global MODEL
    print("Building Cobaya model (CAMB + Planck 2018 lite likelihoods)...",
          flush=True)
    MODEL = build_model()
    x0 = np.array([START[n] * SCALE[n] for n in PARAM_ORDER])
    print("chi2 at Planck published best-fit: %.3f"
          % chi2_of(x0), flush=True)

    free = run_fit("free-ns", free_ns=True, x0_dict=START)
    with open("/home/hatch/workspace/vsl-planck/results/null_test_free.json",
              "w") as f:
        json.dump({"free_fit": free}, f, indent=2)
    print("Checkpoint: free fit saved.", flush=True)
    fixed = run_fit("vsl-fixed-ns", free_ns=False, x0_dict=free["best_fit"])

    dchi2 = fixed["chi2"] - free["chi2"]
    p_value = float(chi2_dist.sf(dchi2, 1)) if dchi2 >= 0 else 1.0
    planck_ns, planck_sig = 0.9649, 0.0042
    naive_sigma = abs(planck_ns - NS_VSL) / np.sqrt(
        planck_sig**2 + NS_VSL_THEORY_ERR**2)

    out = {
        "ns_vsl": NS_VSL,
        "ns_vsl_theory_err": NS_VSL_THEORY_ERR,
        "free_fit": free,
        "vsl_fixed_fit": fixed,
        "delta_chi2": float(dchi2),
        "p_value_1dof": p_value,
        "naive_gaussian_sigma": float(naive_sigma),
        "notes": (
            "r fixed to 0 in both fits (Planck gives only an upper bound; "
            "VSL predicts exactly 0). A_planck fixed to 1. Likelihoods: "
            "Planck 2018 high-l TTTEEE lite + low-l TT + low-l EE. "
            "Theory: CAMB. Minimizer: Nelder-Mead from Planck 2018 best fit."
        ),
    }
    with open("/home/hatch/workspace/vsl-planck/results/null_test.json",
              "w") as f:
        json.dump(out, f, indent=2)
    print("\n==== RESULT ====", flush=True)
    print(f"chi2 free-ns       : {free['chi2']:.3f}", flush=True)
    print(f"chi2 VSL fixed-ns  : {fixed['chi2']:.3f}", flush=True)
    print(f"Delta chi2 (1 dof) : {dchi2:.3f}   p = {p_value:.3f}", flush=True)
    print(f"Naive Gaussian     : {naive_sigma:.3f} sigma", flush=True)
    print("Wrote results/null_test.json", flush=True)


if __name__ == "__main__":
    main()
