"""Polish the free-ns minimum starting from the VSL-fixed best fit (ns freed).
The fixed fit found chi2=1003.008 < free fit's 1003.045, so the free minimizer
stopped marginally short; refining from the fixed point tightens the free min.
"""
import json
import os
import time

import numpy as np
from scipy.optimize import minimize

os.environ["COBAYA_PACKAGES_PATH"] = "/home/hatch/workspace/vsl-planck/data"

from cobaya.model import get_model
from null_test import PARAM_ORDER, SCALE, chi2_of, build_model
import null_test

with open("/home/hatch/workspace/vsl-planck/results/null_test.json") as f:
    prev = json.load(f)

fixed_best = prev["vsl_fixed_fit"]["best_fit"]
x0 = np.array([fixed_best[n] * SCALE[n] for n in PARAM_ORDER])
# free ns from the fixed value
x0[PARAM_ORDER.index("ns")] = 0.96478 * SCALE["ns"]

print("Building model...", flush=True)
null_test.MODEL = build_model()
N = [0]
best = [1e18]

def f(v):
    c2 = chi2_of(np.array(v), free_ns=True)
    N[0] += 1
    best[0] = min(best[0], c2)
    if N[0] % 25 == 0:
        print(f"eval {N[0]}: chi2={c2:.3f} best={best[0]:.3f}", flush=True)
    return c2

t0 = time.time()
res = minimize(f, x0, method="Powell",
               options={"maxiter": 30, "xtol": 1e-4, "ftol": 0.05,
                        "disp": False})
print(f"polished free chi2 = {res.fun:.3f} ({N[0]} evals, "
      f"{time.time()-t0:.0f}s)", flush=True)
bf = {n: float(res.x[i]) / SCALE[n] for i, n in enumerate(PARAM_ORDER)}
print("best-fit:", " ".join(f"{k}={v:.6g}" for k, v in bf.items()),
      flush=True)

prev["free_fit_polished"] = {"chi2": float(res.fun), "best_fit": bf,
                             "evals": N[0]}
dchi2 = prev["vsl_fixed_fit"]["chi2"] - float(res.fun)
prev["delta_chi2_polished"] = float(dchi2)
with open("/home/hatch/workspace/vsl-planck/results/null_test.json",
          "w") as f:
    json.dump(prev, f, indent=2)
print(f"Delta chi2 (fixed - free, polished) = {dchi2:.3f}", flush=True)
